#ifndef CREATURE_H
#define CREATURE_H
#include <string>
#include <iostream>


class Creature {
public:
  std::string name;
  int constitution;
  int dexterity;
  int strength;
  int intelligence;
  int wisdom;
  int charisma;
  int hitPoints;
  int armorClass;
  int conmod;
  int dexmod;
  int strmod;
  int intmod;
  int wismod;
  int chamod;
  bool IsProne;
  bool HasAdvantage;
  bool HasDisadvantage;

  void SetName(std::string nameset) { name = nameset; }
  void SetConstitution(int constitutionset) { constitution = constitutionset; }
  void SetDexterity(int dexterityset) { dexterity = dexterityset; }
  void SetStrength(int strengthset) { strength = strengthset; }
  void SetIntelligence(int intelligenceset) { intelligence = intelligenceset; }
  void SetWisdom(int wisdomset) { wisdom = wisdomset; }
  void SetCharisma(int charismaset) { charisma = charismaset; }
  void SetHitPoints(int hitPointsset) { hitPoints = hitPointsset; }
  void SetarmorClass(int armorClassset) { armorClass = armorClassset; }
  void SetConmod(int conmodset) { conmod = conmodset; }
  void SetDexmod(int dexmodset) { dexmod = dexmodset; }
  void SetStrmod(int strmodset) { strmod = strmodset; }
  void SetIntmod(int intmodset) { intmod = intmodset; }
  void SetWismod(int wismodset) { wismod = wismodset; }
  void SetChamod(int chamodset) { chamod = chamodset; }
  std::string GetName() { return name; }
  int GetConstitution() { return constitution; }
  int GetDexterity() { return dexterity; }
  int GetStrength() { return strength; }
  int GetIntelligence() { return intelligence; }
  int GetWisdom() { return wisdom; }
  int GetCharisma() { return charisma; }
  int GetHitPoints() { return hitPoints; }
  int GetArmorClass() { return armorClass; }
  int GetConmod() { return conmod; }
  int GetDexmod() { return dexmod; }
  int GetStrmod() { return strmod; }
  int GetIntmod() { return intmod; }
  int GetWismod() { return wismod; }
  int GetChamod() { return chamod; }

  void PrintStats() {
    std::cout << "Name: " << GetName() << "\n";
    std::cout << "Constitution: " << GetConstitution() << "\n";
    std::cout << "Dexterity: " << GetDexterity() << "\n";
    std::cout << "Strength: " << GetStrength() << "\n";
    std::cout << "Intelligence: " << GetIntelligence() << "\n";
    std::cout << "Wisdom: " << GetWisdom() << "\n";
    std::cout << "Charisma: " << GetCharisma() << "\n";
    std::cout << "Hit Points: " << GetHitPoints() << "\n";
    std::cout << "Armor Class: " << GetArmorClass() << "\n";
    if (GetConmod() > 0) {
      std::cout << "Constitution Modifier: +" << GetConmod() << "\n";
    }
    if (GetConmod() < 0) {
      std::cout << "Constitution Modifier: -" << GetConmod() << "\n";
    } else {
      std::cout << "Constitution Modifier: " << GetConmod() << "\n";
    }
    if (GetDexmod() > 0) {
      std::cout << "Dexterity Modifier: +" << GetDexmod() << "\n";
    }
    if (GetDexmod() < 0) {
      std::cout << "Dexterity Modifier: -" << GetDexmod() << "\n";
    } else {
      std::cout << "Dexterity Modifier: " << GetDexmod() << "\n";
    }
    if (GetStrmod() > 0) {
      std::cout << "Strength Modifier: +" << GetStrmod() << "\n";
    }
    if (GetStrmod() < 0) {
      std::cout << "Strength Modifier: -" << GetStrmod() << "\n";
    } else {
      std::cout << "Strength Modifier: " << GetStrmod() << "\n";
    }
    if (GetIntmod() > 0) {
      std::cout << "Intelligence Modifier: +" << GetIntmod() << "\n";
    }
    if (GetIntmod() < 0) {
      std::cout << "Intelligence Modifier: -" << GetIntmod() << "\n";
    } else {
      std::cout << "Intelligence Modifier: 0"
                << "\n";
    }
    if (GetWismod() > 0) {
      std::cout << "Wisdom Modifier: +" << GetWismod() << "\n";
    }
    if (GetWismod() < 0) {
      std::cout << "Wisdom Modifier: -" << GetWismod() << "\n";
    } else {
      std::cout << "Wisdom Modifier: 0"
                << "\n";
    }
    if (GetChamod() > 0) {
      std::cout << "Charisma Modifier: +" << GetChamod() << "\n";
    }
    if (GetChamod() < 0) {
      std::cout << "Charisma Modifier: -" << GetChamod() << "\n";
    } else {
      std::cout << "Charisma Modifier: 0"
                << "\n";
    }

    Creature();
  };
};










#endif