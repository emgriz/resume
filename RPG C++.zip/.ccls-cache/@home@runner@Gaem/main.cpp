/*#include "./Creatures/armor.h"
#include "./Creatures/gamelogicfunction.h"
#include "./Creatures/inventory.h"
#include "./Creatures/item.h"
#include "./Creatures/monsters.h"
#include "./Creatures/playerclass.h"
#include "./Creatures/rings.h"
#include "./Creatures/weapons.h"
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <iostream>
#include <string>
#include <unistd.h>
#include <vector>
using namespace std;

// CreateShortsword function moved to testingcenter.cpp for now

// TestEncounter function moved to testingcenter.cpp for now

// ---------------------------------------------------------------------------------
void openMenu(
    Inventory &inventory) { // make a switch statement to control this function
  std::cout << "Menu:" << std::endl;
  std::cout << "1. Return to Game" << std::endl;
  std::cout << "2. Enter Battle" << std::endl;
  std::cout << "3. Open Inventory" << std::endl;
  std::cout << "4. Open Shop" << std::endl;
  std::cout << "5. Start Dialogue" << std::endl;
  std::cout << "6. Open Map" << std::endl;
  std::cout << "7. Save Game" << std::endl;
  std::cout << "8. Quit" << std::endl;
}

void closeMenu() { std::cout << "Menu Closed" << std::endl; } // option 1

void enterBattle() {
  std::cout << "You have entered battle" << std::endl;
} // option 2

void openInventory(const Inventory &inventory) {
  std::cout << "You have opened your inventory" << std::endl;
  inventory.printInventory();
} // option 3

void enterShop() {
  std::cout << "You have entered the shop" << std::endl;
} // option 4

void chat() {
  std::cout << "You have started a dialogue" << std::endl;
} // option 5

void openMap() {
  std::cout << "You have opened the map" << std::endl;
} // option 6

void quitGame() {
  std::cout << "You have quit the game" << std::endl;
} // option 8

// ---------------------------------------------------------------------------------

void saveGame(const Player &player, const Inventory &inventory) {
  ofstream file("save.txt", ios::out | ios::trunc);
  if (!file.is_open()) { // for debugging
    std::cout << "Error opening save file." << std::endl;
    return;
  }
  file << player.name << endl;
  file << player.constitution << endl;
  file << player.dexterity << endl;
  file << player.strength << endl;
  file << player.intelligence << endl;
  file << player.wisdom << endl;
  file << player.charisma << endl;
  file << player.hitPoints << endl;
  file << player.armorClass << endl;
  file << player.conmod << endl;
  file << player.dexmod << endl;
  file << player.strmod << endl;
  file << player.intmod << endl;
  file << player.wismod << endl;
  file << player.chamod << endl;
  file << player.IsProne << endl;
  file << player.HasAdvantage << endl;
  file << player.HasDisadvantage << endl;
  Inventory::inventoryNode *temp = inventory.head;
  while (temp != nullptr) {
    file << temp->item->getName() << endl;
    temp = temp->nextItem;
  }
  file.close();
}

// ADD INVENTORY CAPABILITY
void loadSavedGame(vector<string> &myVec, Player &Player,
                   Inventory &inventory) {
  ifstream file("save.txt");
  if (!file.is_open()) {
    std::cout << "Error opening save file." << std::endl;
    return;
  }
  string line;
  while (getline(file, line)) {
    myVec.push_back(line);
  }
  if (myVec.size() >= 14) {
    // sets the player's stats to the values in the vector of strings
    Player.name = myVec[0];
    // stoi function converts string to int value
    Player.constitution = stoi(myVec[1]);
    Player.dexterity = stoi(myVec[2]);
    Player.strength = stoi(myVec[3]);
    Player.intelligence = stoi(myVec[4]);
    Player.wisdom = stoi(myVec[5]);
    Player.charisma = stoi(myVec[6]);
    Player.hitPoints = stoi(myVec[7]);
    Player.armorClass = stoi(myVec[8]);
    Player.conmod = stoi(myVec[9]);
    Player.dexmod = stoi(myVec[10]);
    Player.strmod = stoi(myVec[11]);
    Player.intmod = stoi(myVec[12]);
    Player.wismod = stoi(myVec[13]);
    Player.chamod = stoi(myVec[14]);

    if (myVec.size() >= 15) {
      // sets the boolean values to 0 (for now, might change)
      Player.IsProne = (myVec[15] == "0");
      Player.HasAdvantage = (myVec[16] == "0");
      Player.HasDisadvantage = (myVec[17] == "0");
    }
  } else {
    std::cout << "Error. Data in save file cannot be loaded." << std::endl;
  }
}
int main() {
  vector<string> Data;
  bool IsNewGame = false;
  bool PbuyLoop = true;
  while (IsNewGame == false) {
    Player user = Player(); // creates the Player object
    user.SetConstitution(8);
    user.SetDexterity(8);
    user.SetStrength(8);
    user.SetIntelligence(8);
    user.SetWisdom(8);
    user.SetCharisma(8);
    bool VisitedConstitution = false;
    bool VisitedDexterity = false;
    bool VisitedStrength = false;
    bool VisitedIntelligence = false;
    bool VisitedWisdom = false;
    bool VisitedCharisma = false;
    do {
      int points = 27;

      std::cout << "Hello! Welcome to the game!"
                << "\n\n";
      sleep(2);
      std::cout << "Because this is a blatant ripoff of DnD 5e "
                   "mechanics, you get to use pointbuy!"
                << "\n\n";
      sleep(2);
      std::cout << "This means that you have a certain number of points "
                   "to distribute across the stats of your character."
                << "\n\n";
      sleep(2);
      std::cout << "All of your stats start with a value of 8, and you can "
                   "increase them up to a maximum of 15 to start. Each stat "
                   "you increase beyond 13 costs 2 points instead of 1."
                << "\n\n";
      sleep(2);
      bool nameloop = true;

      while (nameloop == true) {
        std::cout << "Please choose a name: ";
        std::string namein;
        getline(std::cin, namein);
        user.SetName(namein);
        std::cout << "\nAre you sure you want your name to be "
                  << user.GetName() << "?" << std::endl;
        std::cout << "1. Yes" << std::endl << "2. No" << std::endl;
        int namechoice;
        std::cin >> namechoice;
        std::cin.ignore();
        if (namechoice == 1) {
          nameloop = false;
          std::cout << "\n\nWelcome, " << user.GetName() << "!" << std::endl;
        }
        if (namechoice == 2) {
          nameloop = true;
          std::cout << "\n";
        }
      }

      while (points > 0) {
        std::cout << "\nYou have " << points
                  << " points to distribute among your stats."
                  << "\n\n";
        sleep(1);
        std::cout << "Please choose a stat to increase:" << std::endl;
        std::cout << "1. Constitution" << std::endl;
        std::cout << "2. Dexterity" << std::endl;
        std::cout << "3. Strength" << std::endl;
        std::cout << "4. Intelligence" << std::endl;
        std::cout << "5. Wisdom" << std::endl;
        std::cout << "6. Charisma"
                  << "\n\n";
        int statchoice;
        std::cin >> statchoice;
        switch (statchoice) {
        case 1:
          if (VisitedConstitution == true) {
            std::cout << "You have already increased Constitution. If "
                         "unhappy, reset."
                      << "\n\n";
            break;
          } else {
            std::cout << "What would you like your Constitution to be? You "
                         "can increase it up to 15."
                      << std::endl;
            int finalconstvalue;
            std::cin >> finalconstvalue;
            int constpointscost;
            if (finalconstvalue > 13) {
              constpointscost =
                  ((finalconstvalue - 13) * 2) + (finalconstvalue - 8);
            } else {
              constpointscost = finalconstvalue - 8;
            }
            points = points - constpointscost;
            std::cout << "Your Constitution is now " << finalconstvalue << "."
                      << std::endl;
            std::cout << "This cost you " << constpointscost << " points."
                      << std::endl;
            std::cout << "Would you like to undo this?" << std::endl;
            std::cout << "1. Yes" << std::endl << "2. No" << std::endl;
            int constundochoice;
            std::cin >> constundochoice;
            if (constundochoice == 1) {
              points = points + constpointscost;
            }
            if (constundochoice == 2) {
              user.SetConstitution(finalconstvalue);
              VisitedConstitution = true;
            }
          }
          break;

        case 2:
          if (VisitedDexterity == true) {
            std::cout << "You have already increased Dexterity. If "
                         "unhappy, reset."
                      << "\n\n";
            break;
          } else {
            std::cout << "What would you like your Dexterity to be? You "
                         "can increase it up to 15."
                      << std::endl;
            int finaldexvalue = 0;
            std::cin >> finaldexvalue;
            int dexpointscost;
            if (finaldexvalue > 13) {
              dexpointscost = ((finaldexvalue - 13) * 2) + (finaldexvalue - 8);
            } else {
              dexpointscost = finaldexvalue - 8;
            }

            points = points - dexpointscost;
            std::cout << "Your Dexterity is now " << finaldexvalue << "."
                      << std::endl;
            std::cout << "This cost you " << dexpointscost << " points."
                      << std::endl;
            std::cout << "Would you like to undo this?" << std::endl;
            std::cout << "1. Yes" << std::endl << "2. No" << std::endl;
            int dexundochoice;
            std::cin >> dexundochoice;
            if (dexundochoice == 1) {
              points = points + dexpointscost;
            }
            if (dexundochoice == 2) {
              user.SetDexterity(finaldexvalue);
              VisitedDexterity = true;
            }
          }
          break;

        case 3:
          if (VisitedStrength == true) {
            std::cout << "You have already increased Strength. If "
                         "unhappy, reset."
                      << "\n\n";
            break;
          } else {
            std::cout << "What would you like your Strength to be? You can "
                         "increase it up to 15."
                      << std::endl;
            int finalstrvalue;
            std::cin >> finalstrvalue;
            int strpointscost;
            if (finalstrvalue > 13) {
              strpointscost = ((finalstrvalue - 13) * 2) + (finalstrvalue - 8);
            } else {
              strpointscost = finalstrvalue - 8;
            }
            points = points - strpointscost;
            std::cout << "Your Strength is now " << finalstrvalue << "."
                      << std::endl;
            std::cout << "This cost you " << strpointscost << " points."
                      << std::endl;
            std::cout << "Would you like to undo this?" << std::endl;
            std::cout << "1. Yes" << std::endl << "2. No" << std::endl;
            int strundochoice;
            std::cin >> strundochoice;
            if (strundochoice == 1) {
              points = points + strpointscost;
            }
            if (strundochoice == 2) {
              user.SetStrength(finalstrvalue);
              VisitedStrength = true;
            }
          }
          break;

        case 4:
          if (VisitedIntelligence == true) {
            std::cout << "You have already increased Intelligence. If "
                         "unhappy, reset."
                      << "\n\n";
            break;
          } else {
            std::cout << "What would you like your Intelligence to be? You "
                         "can increase it up to 15."
                      << std::endl;
            int finalintvalue;
            std::cin >> finalintvalue;
            int intpointscost;
            if (finalintvalue > 13) {
              intpointscost = ((finalintvalue - 13) * 2) + (finalintvalue - 8);
            } else {
              intpointscost = finalintvalue - 8;
            }
            points = points - intpointscost;
            std::cout << "Your Intelligence is now " << finalintvalue << "."
                      << std::endl;
            std::cout << "This cost you " << intpointscost << " points."
                      << std::endl;
            std::cout << "Would you like to undo this?" << std::endl;
            std::cout << "1. Yes" << std::endl << "2. No" << std::endl;
            int intundochoice;
            std::cin >> intundochoice;
            if (intundochoice == 1) {
              points = points + intpointscost;
            }
            if (intundochoice == 2) {
              user.SetIntelligence(finalintvalue);
              VisitedIntelligence = true;
            }
          }
          break;

        case 5:
          if (VisitedWisdom == true) {
            std::cout << "You have already increased Wisdom. If unhappy, reset."
                      << "\n\n";
            break;
          } else {
            std::cout << "What would you like your Wisdom to be? You can "
                         "increase it up to 15."
                      << std::endl;
            int finalwisvalue;
            std::cin >> finalwisvalue;
            int wispointscost;
            if (finalwisvalue > 13) {
              wispointscost = ((finalwisvalue - 13) * 2) + (finalwisvalue - 8);
            } else {
              wispointscost = finalwisvalue - 8;
            }
            points = points - wispointscost;
            std::cout << "Your Wisdom is now " << finalwisvalue << "."
                      << std::endl;
            std::cout << "This cost you " << wispointscost << " points."
                      << std::endl;
            std::cout << "Would you like to undo this?" << std::endl;
            std::cout << "1. Yes" << std::endl << "2. No" << std::endl;
            int wisundochoice;
            std::cin >> wisundochoice;
            if (wisundochoice == 1) {
              points = points + wispointscost;
            }
            if (wisundochoice == 2) {
              user.SetWisdom(finalwisvalue);
              VisitedWisdom = true;
            }
          }
          break;

        case 6:
          if (VisitedCharisma == true) {
            std::cout << "You have already increased Charisma. If "
                         "unhappy, reset."
                      << "\n\n";
            break;
          } else {
            std::cout << "What would you like your Charisma to be? You can "
                         "increase it up to 15."
                      << std::endl;
            int finalchavalue;
            std::cin >> finalchavalue;
            int chapointscost;
            if (finalchavalue > 13) {
              chapointscost = ((finalchavalue - 13) * 2) + (finalchavalue - 8);
            } else {
              chapointscost = finalchavalue - 8;
            }
            points = points - chapointscost;
            std::cout << "Your Charisma is now " << finalchavalue << "."
                      << std::endl;
            std::cout << "This cost you " << chapointscost << " points."
                      << std::endl;
            std::cout << "Would you like to undo this?" << std::endl;
            std::cout << "1. Yes" << std::endl << "2. No" << std::endl;
            int chaundochoice;
            std::cin >> chaundochoice;
            if (chaundochoice == 1) {
              points = points + chapointscost;
            }
            if (chaundochoice == 2) {
              user.SetCharisma(finalchavalue);
              VisitedCharisma = true;
            }
          }
          std::cout << "Points left: " << points << "\n\n";
          break;
        } // end of switch statement

        std::cout << "Here are your final stats:" << std::endl;
        std::cout << "Name: " << user.GetName() << std::endl;
        std::cout << "Constitution: " << user.GetConstitution() << std::endl;
        std::cout << "Dexterity: " << user.GetDexterity() << std::endl;
        std::cout << "Strength: " << user.GetStrength() << std::endl;
        std::cout << "Intelligence: " << user.GetIntelligence() << std::endl;
        std::cout << "Wisdom: " << user.GetWisdom() << std::endl;
        std::cout << "Charisma: " << user.GetCharisma() << "\n\n";
        sleep(2);
        std::cout << "Is this okay?" << std::endl;
        std::cout << "1. Yes" << std::endl;
        std::cout << "2. No" << std::endl;
        int pbuychoice;
        std::cin >> pbuychoice;
        if (pbuychoice == 1) {
          PbuyLoop = false;
        }
        if (pbuychoice == 2) {
          PbuyLoop = true;
          VisitedConstitution = false;
          VisitedDexterity = false;
          VisitedStrength = false;
          VisitedIntelligence = false;
          VisitedWisdom = false;
          VisitedCharisma = false;
        }
      }
    } while (PbuyLoop == true && VisitedConstitution == true &&
             VisitedDexterity == true && VisitedStrength == true &&
             VisitedIntelligence == true && VisitedWisdom == true &&
             VisitedCharisma == true);
  } // while points>0
  return 0;
}

// end of int main

std::cout << "Please choose a class!" << std::endl;
sleep(1);
std::cout << "1. Barbarian" << std::endl;
std::cout << "2. Wizard" << std::endl;
int classchoice;
std::cin >> classchoice;
if (classchoice == 1) {
  user.SetClass("Barbarian");
  IsNewGame = false;
}
if (classchoice == 2) {
  user.SetClass("Wizard");
  IsNewGame = false;
}
} // NewGameLoop

openMenu();
}
*/
