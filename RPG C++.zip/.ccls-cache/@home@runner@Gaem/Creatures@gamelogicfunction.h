#ifndef GAMELOGICFUNCTION_H
#define GAMELOGICFUNCTION_H

#include "creatureclass.h"
#include <cstdlib>

class gameLogicFunctions {
public:
  int rollDie(int dieType = 20, bool hasAdvantage = false,
              bool hasDisadvantage = false, int count = 1) {
    int roll = 0;
    if (hasAdvantage && !hasDisadvantage) {
      int x = (rand() % dieType) + 1;
      int y = (rand() % dieType) + 1;
      roll = (x >= y) ? x : y;
    } else if (!hasAdvantage && hasDisadvantage) {
      int x = (rand() % dieType) + 1;
      int y = (rand() % dieType) + 1;
      roll = (x <= y) ? x : y;
    } else {
      roll = (rand() % dieType) + 1;
    }
    return roll;
  }
};

#endif
