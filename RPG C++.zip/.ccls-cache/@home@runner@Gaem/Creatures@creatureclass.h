#ifndef CREATURE_H
#define CREATURE_H
#include <iostream>
#include <string>

class Creature {
public:
virtual ~Creature() {}

  std::string name;
  int constitution;
  int dexterity;
  int strength;
  int intelligence;
  int wisdom;
  int charisma;
  int hitPoints;
  int armorClass;
  int conmod;
  int dexmod;
  int strmod;
  int intmod;
  int wismod;
  int chamod;
		int actionsremaining;
  int initiative;
  bool IsProne;
  bool HasAdvantage;
  bool HasDisadvantage;
  bool IsFleeing;
  bool defending;
  int poison;
  int regeneration;
		int firstspellslots;
		int secondspellslots;
		int thirdspellslots;
		

  void SetName(std::string nameset) { name = nameset; }
  void SetInitiative(int initiativeset){
    initiative = initiativeset;
  }
  void SetConstitution(int constitutionset) { constitution = constitutionset; }
  void SetDexterity(int dexterityset) { dexterity = dexterityset; }
  void SetStrength(int strengthset) { strength = strengthset; }
  void SetIntelligence(int intelligenceset) { intelligence = intelligenceset; }
  void SetWisdom(int wisdomset) { wisdom = wisdomset; }
  void SetCharisma(int charismaset) { charisma = charismaset; }
  void SetHitPoints(int hitPointsset) { hitPoints = hitPointsset; }
  void SetarmorClass(int armorClassset) { armorClass = armorClassset; }
  void SetConmod(int conmodset) { conmod = conmodset; }
  void SetDexmod(int dexmodset) { dexmod = dexmodset; }
  void SetStrmod(int strmodset) { strmod = strmodset; }
  void SetIntmod(int intmodset) { intmod = intmodset; }
  void SetWismod(int wismodset) { wismod = wismodset; }
  void SetChamod(int chamodset) { chamod = chamodset; }
		void SetRegen(int regenset) {regeneration = regenset; }
		void SetPoison(int poisonset) {poison = poisonset; }
		void Setactionsremaining(int actionset) {actionsremaining = actionset;}
  virtual std::string GetName() { return name; }
		int Getactionsremaining(){return actionsremaining;}
  int GetConstitution() { return constitution; }
  int GetDexterity() { return dexterity; }
  int GetStrength() { return strength; }
  int GetIntelligence() { return intelligence; }
  int GetWisdom() { return wisdom; }
  int GetCharisma() { return charisma; }
  int GetHitPoints() { return hitPoints; }
  int GetArmorClass() { return armorClass; }
  int GetConmod() { return conmod; }
  int GetDexmod() { return dexmod; }
  int GetStrmod() { return strmod; }
  int GetIntmod() { return intmod; }
  int GetWismod() { return wismod; }
  int GetChamod() { return chamod; }
  int GetInitiative() { return initiative; }
		int GetRegen() {return regeneration;}
		int GetPoison() {return poison;}
  virtual void SetTestStats() {
    SetName("Cephandrius");
    SetConstitution(10);
    SetDexterity(10);
    SetStrength(10);
    SetIntelligence(10);
    SetWisdom(10);
    SetCharisma(10);
    SetHitPoints(30);
    SetarmorClass(15);
    SetConmod(1);
    SetDexmod(1);
    SetStrmod(1);
    SetIntmod(1);
    SetWismod(1);
    SetChamod(1);
				Setactionsremaining(1);
				firstspellslots = 2;
				secondspellslots = 1;
				thirdspellslots = 0;
  }
  void PrintStats() {
    std::cout << "Name: " << GetName() << "\n";
    std::cout << "Constitution: " << GetConstitution() << "\n";
    std::cout << "Dexterity: " << GetDexterity() << "\n";
    std::cout << "Strength: " << GetStrength() << "\n";
    std::cout << "Intelligence: " << GetIntelligence() << "\n";
    std::cout << "Wisdom: " << GetWisdom() << "\n";
    std::cout << "Charisma: " << GetCharisma() << "\n";
    std::cout << "Hit Points: " << GetHitPoints() << "\n";
    std::cout << "Armor Class: " << GetArmorClass() << "\n";
				std::cout << "First Level Spell Slots Remaining: " << firstspellslots << "\n";
				std::cout << "Second Level Spell Slots Remaining: " << secondspellslots << "\n";
				std::cout << "Third Level Spell Slots Remaining: " << thirdspellslots << "\n";
    if (GetConmod() > 0) {
      std::cout << "Constitution Modifier: +" << GetConmod() << "\n";
    }
    if (GetConmod() < 0) {
      std::cout << "Constitution Modifier: -" << GetConmod() << "\n";
    } 
				if(GetConmod() == 0) {
      std::cout << "Constitution Modifier: " << GetConmod() << "\n";
    }
    if (GetDexmod() > 0) {
      std::cout << "Dexterity Modifier: +" << GetDexmod() << "\n";
    }
    if (GetDexmod() < 0) {
      std::cout << "Dexterity Modifier: -" << GetDexmod() << "\n";
    } 
				if (GetDexmod() == 0) {
      std::cout << "Dexterity Modifier: " << GetDexmod() << "\n";
    }
    if (GetStrmod() > 0) {
      std::cout << "Strength Modifier: +" << GetStrmod() << "\n";
    }
    if (GetStrmod() < 0) {
      std::cout << "Strength Modifier: -" << GetStrmod() << "\n";
    } 
				if (GetStrmod() == 0) {
      std::cout << "Strength Modifier: " << GetStrmod() << "\n";
    }
    if (GetIntmod() > 0) {
      std::cout << "Intelligence Modifier: +" << GetIntmod() << "\n";
    }
    if (GetIntmod() < 0) {
      std::cout << "Intelligence Modifier: -" << GetIntmod() << "\n";
    } 
				if (GetIntmod() == 0) {
      std::cout << "Intelligence Modifier: 0" << "\n";
    }
    if (GetWismod() > 0) {
      std::cout << "Wisdom Modifier: +" << GetWismod() << "\n";
    }
    if (GetWismod() < 0) {
      std::cout << "Wisdom Modifier: -" << GetWismod() << "\n";
    } if (GetWismod() == 0) {
      std::cout << "Wisdom Modifier: 0 " << "\n";
    }
    if (GetChamod() > 0) {
      std::cout << "Charisma Modifier: +" << GetChamod() << "\n";
    }
    if (GetChamod() < 0) {
      std::cout << "Charisma Modifier: -" << GetChamod() << "\n";
    } if (GetChamod() == 0) {
      std::cout << "Charisma Modifier: 0" << "\n";
    }
   
		}

    Creature() = default;
 
};

// write an update function to set the modifiers to stats properly.

#endif