#ifndef ARMORCLASS_H
#define ARMORCLASS_H
#include "gamelogicfunction.h"
#include "item.h"
#include <string>

class Armor : public Item {
public:
  std::string name;
  int dexterity;
  int armor;
  int constitution;
  int hitPoints;
  int strength;
  int weight;

  void setName(std::string nameset) { name = nameset; }
  void setConstitution(int constitutionset) { constitution = constitutionset; }
  void setDexterity(int dexterityset) { dexterity = dexterityset; }
  void setStrength(int strengthset) { strength = strengthset; }
  void setHitPoints(int hitPointsset) { hitPoints = hitPointsset; }
  void setArmor(int armorClassset) { armor = armorClassset; }
  void setWeight(int weightset) { weight = weightset; }

  std::string getName() { return name; }
  int getConstitution() { return constitution; }
  int getDexterity() { return dexterity; }
  int getStrength() { return strength; }
  int getHitPoints() { return hitPoints; }
  int getArmor() { return armor; }
  int geWeight() { return weight; }
  Armor() = default;
};

#endif