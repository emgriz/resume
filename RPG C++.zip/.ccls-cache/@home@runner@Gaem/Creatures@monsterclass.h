#ifndef MONSTERCLASS_H
#define MONSTERCLASS_H
#include "creatureclass.h"
#include <string>
#include "playerclass.h" 

class Monster : public Creature {
public:
  double CR;
  int XPvalue;
  std::string name;
		char MapSymbol;

virtual void chooseAction(Creature& target) = 0;

virtual char getMapSymbol() {return MapSymbol;}
virtual void setMapSymbol(char newMapSymbol){MapSymbol = newMapSymbol;}

  Monster() : Creature() {
    CR = 0;
    XPvalue = 0;
				MapSymbol = '0';
  }

};

#endif