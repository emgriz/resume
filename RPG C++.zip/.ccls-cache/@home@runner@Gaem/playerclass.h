#ifndef PLAYERCLASS_H
#define PLAYERCLASS_H
#include "creatureclass.h"
#include <string>
#include <vector>

class Player : public Creature {
public:
  int GetLevel() { return level; }
  int GetExperience() { return experience; }
  std::string GetClass() { return Class; }
  void SetLevel(int levelset) { level = levelset; }
  void SetExperience(int experienceset) { experience = experienceset; }
  void SetClass(std::string classset) { Class = classset; }

  Player() : Creature() {
    level = 1;
    experience = 0;
    Class = "DefaultClass";
    Race = "DefaultRace";
  }

protected:
  int level;
  int experience;
  std::string Class;
  std::string Race;
};

#endif