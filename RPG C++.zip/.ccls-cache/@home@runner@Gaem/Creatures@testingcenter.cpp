// this file is for perfecting the test encounter function so we can fill
// "main.cpp" with the complete code that works

#include "./Creatures/gamelogicfunction.h"
#include "./Creatures/inventory.h"
#include "./Creatures/monsters.h"
#include "./Creatures/playerclass.h"
#include "./Creatures/spells.h"
#include "./Creatures/weapons.h"
#include <algorithm>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <iostream>
#include <queue>
#include <stack>
#include <string>
#include <time.h>
#include <unistd.h>
#include <unordered_set>
#include <vector>

using namespace std;

void InitializeSpells(Player &player) {
  Fire_Bolt *FireBolt = new Fire_Bolt();
  FireBolt->setName("Fire Bolt");
  FireBolt->setDamageDie(10);
  FireBolt->setSpellSlot(0);
  FireBolt->setDamageType("Fire");
  FireBolt->hasUnlocked = true;
  player.ObtainSpell(FireBolt);
}

void Status(std::queue<Creature *> &TurnQueue,
            std::vector<Creature *> &entities) {
  std::cout << "\n";
  for (auto creature : entities) {
    std::cout << creature->name << " HP: " << creature->GetHitPoints()
              << "   Poison: " << creature->GetPoison()
              << "   Regen: " << creature->GetRegen() << "\n";
  }
  std::cout << "\n";
}

// Function to end turn
void EndTurn(std::queue<Creature *> &TurnQueue,
             std::vector<Creature *> &entities) {
  // Get the creature whose turn it is
  Creature *currentCreature = TurnQueue.front();

  if (currentCreature->GetHitPoints() < 1) {
    std::cout << currentCreature->GetName() << " has died." << std::endl;
    // Delete the creature from entities vector and free memory
    auto it = std::find(entities.begin(), entities.end(), currentCreature);
    if (it != entities.end()) {
      delete *it;         // Free memory for the creature
      entities.erase(it); // Remove from the vector
    }
  }

  // Output the names of remaining creatures in entities vector
  std::cout << "\nRemaining creatures: ";
  for (auto creature : entities) {
    std::cout << creature->GetName() << " ";
  }
  std::cout << "\n";

  // Perform regen and poison effects
  currentCreature->SetHitPoints(currentCreature->GetHitPoints() +
                                currentCreature->GetRegen());
  currentCreature->SetHitPoints(currentCreature->GetHitPoints() -
                                currentCreature->GetPoison());
  if (currentCreature->GetRegen() > 1) {
    currentCreature->SetRegen(currentCreature->GetRegen() - 1);
  }
  if (currentCreature->GetPoison() > 1) {
    currentCreature->SetPoison(currentCreature->GetPoison() - 1);
  }

  // Pop the current creature from the turn queue
  TurnQueue.pop();

  if (currentCreature->GetHitPoints() > 0) {
    TurnQueue.push(currentCreature);
  }
}

void CheckStats(Player &player) {
  std::cout << "Player Stats: \n";
  player.PrintStats();
  std::cout << "Weapon stats: \n";
  player.Equipped_Weapon->PrintStats();
}

void ProcessTurn(std::queue<Creature *> &TurnQueue,
                 std::vector<Creature *> &entities,
                 std::vector<Weapon *> &weapons, Creature *playerptr) {
  // Get the creature whose turn it is
  Creature *currentCreature = TurnQueue.front();

  // Check if the creature is a Player
  Player *currentPlayer = dynamic_cast<Player *>(currentCreature);

  if (currentPlayer) {
    int choice;
    std::cout << "\nIt's your turn, " << currentPlayer->GetName() << "!"
              << std::endl;
    currentPlayer->defending = false;
    while (currentPlayer->actionsremaining > 0) {
      std::cout << "1. Attack" << std::endl;
      std::cout << "2. Defend" << std::endl;
      std::cout << "3. Magic" << std::endl;
      std::cout << "4. Check Stats" << std::endl;
      std::cout << "5. Switch Weapon" << std::endl;
      std::cout << "Enter your choice: ";
      std::cin >> choice;

      // Input validation for choice
      while (choice < 1 || choice > 5) {
        std::cout << "Invalid choice. Please enter a number 1-5: ";
        std::cin >> choice;
      }

      Creature *targetMonster = nullptr;
      switch (choice) {
      case 1:
        // Ask which monster to attack
        std::cout << "\nWhich monster do you want to attack?\n" << std::endl;
        for (int i = 0; i < entities.size(); i++) {
          std::cout << i + 1 << ". " << entities.at(i)->GetName() << std::endl;
        }
        int targetIndex;
        std::cin >> targetIndex;

        // Input validation for targetIndex
        if (targetIndex < 1 || targetIndex > entities.size()) {
          std::cout << "Invalid target index. Please choose a valid index: ";
          std::cin >> targetIndex;
        }

        // Attack the selected monster

        targetMonster = (entities.at(targetIndex - 1));

        currentPlayer->Attack(*targetMonster);
        currentPlayer->actionsremaining--;
        break;

      case 2:
        currentPlayer->Defend();
        currentPlayer->actionsremaining--;
        break;

      case 3:
        currentPlayer->Spellbook();
        int spellchoice;
        cin >> spellchoice;
        if (spellchoice == 1) {
          std::cout << "\nWhich monster do you want to use "
                    << currentPlayer->UnlockedSpells[0]->getName() << " on?"
                    << std::endl;
          for (int i = 0; i < entities.size(); i++) {
            std::cout << i + 1 << ". " << entities.at(i)->GetName()
                      << std::endl;
          }
          int targetIndex;
          std::cin >> targetIndex;
          if (targetIndex < 1 || targetIndex > entities.size()) {
            std::cout << "Invalid target index. Please choose a valid index: ";
            std::cin >> targetIndex;
          }
          targetMonster = (entities.at(targetIndex - 1));
          currentPlayer->UnlockedSpells[0]->Cast(*currentPlayer,
                                                 *targetMonster);
          currentPlayer->actionsremaining--;
        }
        break;
      case 4:
        CheckStats(*currentPlayer);
        break;
      case 5:
        std::cout << "Which weapon do you want to equip?" << std::endl;
        for (auto weapon : weapons) {
          // if unlocked print it as available
          int i = 1;
          if (weapon->hasinInventory == true) {
            std::cout << i << ". " << weapon->getName() << std::endl;
            i++;
          }
        }
        int weaponchoice;
        std::cin >> weaponchoice;

        break;
      default:
        std::cout << "Invalid choice. Please try again." << std::endl;
        break;
      }
    }
  } else {
    // Check if the creature is a Monster
    Monster *currentMonster = dynamic_cast<Monster *>(currentCreature);
    if (currentMonster) {
      std::cout << "\nIt's " << currentMonster->GetName() << "'s turn!"
                << std::endl;
      currentMonster->chooseAction(*playerptr);
    } else {
      // Error handling if the creature is neither a Player nor a Monster
      std::cerr << "Error: Unknown creature type detected in turn processing."
                << std::endl;
    }
  }
}

template <typename GiantFrog, typename Hobgoblin, typename Wolf, typename Guard,
          typename Noble, typename Bugbear>
void CreateEncounter(int nummonsters, Monster *monster1 = nullptr,
                     const std::string &name1 = "", Monster *monster2 = nullptr,
                     const std::string &name2 = "", Monster *monster3 = nullptr,
                     const std::string &name3 = "", Monster *monster4 = nullptr,
                     const std::string &name4 = "", Monster *monster5 = nullptr,
                     const std::string &name5 = "", Monster *monster6 = nullptr,
                     const std::string &name6 = "", Monster *monster7 = nullptr,
                     const std::string &name7 = "", Monster *monster8 = nullptr,
                     const std::string &name8 = "") {

  // initialize player and other nonsense
  std::vector<Weapon *> weapons;
  Player testplayer;
  testplayer.SetTestStats();
  Weapon club;
  club.UpdateClub();
  Weapon longsword;
  longsword.UpdateLongsword();
  Weapon poisonedblade;
  poisonedblade.UpdatePoisonedBlade();
  Weapon adminstick;
  adminstick.UpdateAdminStick();
  weapons.push_back(&club);
  weapons.push_back(&longsword);
  weapons.push_back(&poisonedblade);
  weapons.push_back(&adminstick);
  club.Unlock(&club);

  testplayer.Equipped_Weapon = &adminstick;
  CheckStats(testplayer);
  gameLogicFunctions logic;
  InitializeSpells(testplayer);

  std::vector<Creature *> entities;
  entities.push_back(&testplayer);

  // Add monsters and set their names
  if (monster1 != nullptr) {
    monster1->SetName(name1);
    entities.push_back(monster1);
  }
  if (monster2 != nullptr) {
    monster2->SetName(name2);
    entities.push_back(monster2);
  }
  if (monster3 != nullptr) {
    monster3->SetName(name3);
    entities.push_back(monster3);
  }
  if (monster4 != nullptr) {
    monster4->SetName(name4);
    entities.push_back(monster4);
  }
  if (monster5 != nullptr) {
    monster5->SetName(name5);
    entities.push_back(monster5);
  }
  if (monster6 != nullptr) {
    monster6->SetName(name6);
    entities.push_back(monster6);
  }
  if (monster7 != nullptr) {
    monster7->SetName(name7);
    entities.push_back(monster7);
  }
  if (monster8 != nullptr) {
    monster8->SetName(name8);
    entities.push_back(monster8);
  }

  for (auto creature : entities) {
    int initiative = logic.rollDie(20, false, false) + creature->GetDexmod();
    creature->SetInitiative(initiative); // Set the initiative for each creature
  }

  // Sort entities by initiative
  std::sort(entities.begin(), entities.end(), [](Creature *a, Creature *b) {
    return (a->GetInitiative() > b->GetInitiative());
  });

  // Print the initiative order
  std::cout << "Initiative order: ";
  for (auto creature : entities) {
    std::cout << creature->GetName() << " ";
  }
  std::cout << std::endl;
  std::queue<Creature *> TurnQueue;
  // Start the encounter
  for (auto creature : entities) {
    // load them into the queue
    TurnQueue.push(creature);
  }
  // Process turns until all creatures are defeated

  while (TurnQueue.size() > 1 && testplayer.GetHitPoints() > 0) {
    ProcessTurn(TurnQueue, entities, weapons, &testplayer);
    if (testplayer.GetHitPoints() < 0) {
      std::cout << "\nGet bent, loser! You died.";
    }
    Status(TurnQueue, entities);
    EndTurn(TurnQueue, entities);
  }

} // end enc

// when return, fix attack function, make an equip function, make a healing
// potion function

void saveGame(const Player &player, const Inventory &inventory) {
  ofstream file("save.txt", ios::out | ios::trunc);
  if (!file.is_open()) { // for debugging
    std::cout << "Error opening save file." << std::endl;
    return;
  }
  file << player.name << endl;
  file << player.constitution << endl;
  file << player.dexterity << endl;
  file << player.strength << endl;
  file << player.intelligence << endl;
  file << player.wisdom << endl;
  file << player.charisma << endl;
  file << player.hitPoints << endl;
  file << player.armorClass << endl;
  file << player.conmod << endl;
  file << player.dexmod << endl;
  file << player.strmod << endl;
  file << player.intmod << endl;
  file << player.wismod << endl;
  file << player.chamod << endl;
  file << player.IsProne << endl;
  file << player.HasAdvantage << endl;
  file << player.HasDisadvantage << endl;
  Inventory::inventoryNode *temp = inventory.head;
  while (temp != nullptr) {
    file << temp->item->getName() << endl;
    temp = temp->nextItem;
  }
  file.close();
}

// ADD INVENTORY CAPABILITY
void loadSavedGame(vector<string> &myVec, Player &Player,
                   Inventory &inventory) {
  ifstream file("save.txt");
  if (!file.is_open()) {
    std::cout << "Error opening save file." << std::endl;
    return;
  }
  string line;
  while (getline(file, line)) {
    myVec.push_back(line);
  }
  if (myVec.size() >= 14) {
    // sets the player's stats to the values in the vector of strings
    Player.name = myVec[0];
    // stoi function converts string to int value
    Player.constitution = stoi(myVec[1]);
    Player.dexterity = stoi(myVec[2]);
    Player.strength = stoi(myVec[3]);
    Player.intelligence = stoi(myVec[4]);
    Player.wisdom = stoi(myVec[5]);
    Player.charisma = stoi(myVec[6]);
    Player.hitPoints = stoi(myVec[7]);
    Player.armorClass = stoi(myVec[8]);
    Player.conmod = stoi(myVec[9]);
    Player.dexmod = stoi(myVec[10]);
    Player.strmod = stoi(myVec[11]);
    Player.intmod = stoi(myVec[12]);
    Player.wismod = stoi(myVec[13]);
    Player.chamod = stoi(myVec[14]);

    if (myVec.size() >= 15) {
      // sets the boolean values to 0 (for now, might change)
      Player.IsProne = (myVec[15] == "0");
      Player.HasAdvantage = (myVec[16] == "0");
      Player.HasDisadvantage = (myVec[17] == "0");
    }
  } else {
    std::cout << "Error. Data in save file cannot be loaded." << std::endl;
  }
}

/*int main() {
  srand(time(NULL));

  CreateEncounter<GiantFrog, Hobgoblin, Wolf, Guard, Noble, Bugbear>(
      2, new Wolf(), "Wolf", new Wolf(), "Wolf2");

  return 0;
}*/