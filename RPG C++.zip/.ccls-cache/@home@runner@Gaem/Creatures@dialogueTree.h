#include <iostream>
#include <sstream>
#include <string>
#include <unordered_map>

#include "../testingcenter.h"
#include "monsters.h"

class Node {
public:
  string text;
  unordered_map<int, Node *> options;
  int dc;
  bool hasEncounter = false;
  string choicetext;
  int nummonsters;
  Monster *monster1 = nullptr;
  string name1;
  Monster *monster2 = nullptr;
  string name2;
  Monster *monster3 = nullptr;
  string name3;
  Monster *monster4 = nullptr;
  string name4;
  Monster *monster5 = nullptr;
  string name5;
  Monster *monster6 = nullptr;
  string name6;
  Monster *monster7 = nullptr;
  string name7;
  Monster *monster8 = nullptr;
  string name8;
  bool visited = false;

  void markVisited() { visited = true; }

  std::string serialize() const {
    return text + "," + std::to_string(hasEncounter) + "," +
           std::to_string(visited);
  }

  static Node deserialize(const std::string &serializedData) {
    std::string text;
    bool hasEncounter;
    bool visited;
    // splits the serialized data by comma
    size_t pos1 = serializedData.find(",");
    if (pos1 != std::string::npos) {
      text = serializedData.substr(0, pos1);
      size_t pos2 = serializedData.find(",", pos1 + 1);
      if (pos2 != std::string::npos) {
        hasEncounter =
            std::stoi(serializedData.substr(pos1 + 1, pos2 - pos1 - 1));
        visited = std::stoi(serializedData.substr(pos2 + 1));
      } else {
        // handles invalid input
        hasEncounter = false;
        visited = false;
      }
    } else {
      // handles invalid input
      text = "InvalidNode";
      hasEncounter = false;
      visited = false;
    }
    // creates a new node with the deserialized data
    Node newNode(text, hasEncounter);
    newNode.visited = visited;
    return newNode;
  }

  void RunEncounter(Node *currentNode, int nummonsters,
                    Monster *monster1 = nullptr, const std::string &name1 = "",
                    Monster *monster2 = nullptr, const std::string &name2 = "",
                    Monster *monster3 = nullptr, const std::string &name3 = "",
                    Monster *monster4 = nullptr, const std::string &name4 = "",
                    Monster *monster5 = nullptr, const std::string &name5 = "",
                    Monster *monster6 = nullptr, const std::string &name6 = "",
                    Monster *monster7 = nullptr, const std::string &name7 = "",
                    Monster *monster8 = nullptr,
                    const std::string &name8 = "") {
    if (currentNode->hasEncounter == true) {
      CreateEncounter<GiantFrog, Hobgoblin, Wolf, Guard, Noble, Bugbear>(
          nummonsters, monster1, name1, monster2, name2, monster3, name3,
          monster4, name4, monster5, name5, monster6, name6, monster7, name7,
          monster8, name8);
    }
  }

  Node(string t) : text(t) {}
  Node(string t, bool hasEncounter) : text(t), hasEncounter(hasEncounter) {}
  Node(string t, bool hasEncounter, string nextt, int nummonsters,
       Monster *monster1, string name1, Monster *monster2 = nullptr,
       string name2 = "", Monster *monster3 = nullptr, string name3 = "",
       Monster *monster4 = nullptr, string name4 = "",
       Monster *monster5 = nullptr, string name5 = "",
       Monster *monster6 = nullptr, string name6 = "",
       Monster *monster7 = nullptr, string name7 = "",
       Monster *monster8 = nullptr, string name8 = "")
      : text(t), hasEncounter(hasEncounter), choicetext(nextt),
        monster1(monster1), name1(name1), monster2(monster2), name2(name2),
        monster3(monster3), name3(name3), monster4(monster4), name4(name4),
        monster5(monster5), name5(name5), monster6(monster6), name6(name6),
        monster7(monster7), name7(name7), monster8(monster8), name8(name8) {}
};

class DialogueTree {
public:
  void addNode(Node *node, int option, Node *nextNode) {
    node->options[option] = nextNode;
  }

  void setRoot(Node *node) { root = node; }

  Node *getRoot() const { return root; }

  void saveDialogueTree(std::ofstream &file, Node *currentNode) const {
    file << "STORY_NODE:" << currentNode->serialize() << std::endl;

    // traverses through the options of the current node
    for (const auto &option : currentNode->options) {
      saveDialogueTree(file, option.second);
    }
  }

  DialogueTree() : current(nullptr) {}

  ~DialogueTree() { deleteTree(current); }

private:
  Node *current;
  Node *root;

  void deleteTree(Node *node) {
    if (node) {
      for (auto &option : node->options) {
        deleteTree(option.second);
      }
      delete node;
    }
  }
};