#ifndef QUEUE_H
#define QUEUE_H

#include <iostream>


class Node {
public:
int data;
Node* nextNode;
};


class Queue {
public:
    Node* top;
    Node* bottom;
    int size;

    Queue() : top(nullptr), bottom(nullptr), size(0) {}

  bool isEmpty() {
      return top == nullptr;
  }

    void enqueue(Node* newNode) {
        if (isEmpty()) {
            top = newNode;
            bottom = newNode;
        } else {
            bottom->nextNode = newNode;
            bottom = newNode;
        }
        size++;
    }

    Node* dequeue() {
        if (isEmpty()) {
            std::cout << "Queue is empty. Cannot dequeue.\n";
            return nullptr;
        }

        Node* tempnode = top;
        top = top->nextNode;
        if (top == nullptr) {
            bottom = nullptr;
        }
        size--;
        return tempnode;
    }

    Node* front() {
        return top;
    }

    Node* back() {
        return bottom;
    }



    void popN(int n) {
        for (int i = 0; i < n && !isEmpty(); i++) {
            dequeue();
        }
    }

    int Queuesize() {
        return size;
    }
};


class Stack {
public:

Node* top;
int size;

void push(Node* newNode){
  if(top == NULL){
    top = newNode;
  }//end if
  else
  {
    newNode->nextNode = top;
    top = newNode;
  } //end else
}// end push

Node pop(){
    Node* temp = top;
    top = top->nextNode;
    return *temp;
  }//end pop

Node peek() {
  return *top;
} // end peek

bool isEmpty(){
  if (top == NULL){
    return true;
  }
  else {return false;}
} // end isEmpty



}; // end class Stack



#endif