#ifndef WEAPONS_H
#define WEAPONS_H
/*#include "weaponclass.h"

class Longsword : public Weapon {};
class Dagger : public Weapon {};
class Handaxe : public Weapon {};
class Club : public Weapon{};

class Poisoned_Blade : public Weapon {
public:
				std::string name;
				int onhitPoison;
				int damageDie;
				int damageType;
				int damageModifier;
				int HitMod;

					Poisoned_Blade() : Weapon(){ 
									name = "Cheese Blade";
									onhitPoison = 5;
									damageDie = 4;
									damageType = 2;
									damageModifier = 1;
									HitMod = 3;
										}
void setStats(){
	name = "Cheese Blade";
	onhitPoison = 5;
	damageDie = 4;
	damageType = 2;
	damageModifier = 1;
	HitMod = 3;
}
				std::string getName() const {
								return name;
				}

				void setName(const std::string& newName) {
								name = newName;
				}

				int getOnhitPoison() const {
								return onhitPoison;
				}

				void setonhitPoison(int newOnhitPoison) {
								onhitPoison = newOnhitPoison;
				}

				int getDamageDie() const {
								return damageDie;
				}

				void setDamageDie(int newDamageDie) {
								damageDie = newDamageDie;
				}

				int getDamageType() const {
								return damageType;
				}

				void setDamageType(int newDamageType) {
								damageType = newDamageType;
				}

				int getDamageModifier() const {
								return damageModifier;
				}

				void setDamageModifier(int newDamageModifier) {
								damageModifier = newDamageModifier;
				}

				int getHitMod() const {
								return HitMod;
				}

				void setHitMod(int newHitMod) {
								HitMod = newHitMod;
				}

};
*/
#endif