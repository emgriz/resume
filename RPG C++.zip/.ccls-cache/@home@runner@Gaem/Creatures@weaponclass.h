#ifndef WEAPONCLASS_H
#define WEAPONCLASS_H
#include "gamelogicfunction.h"
#include "item.h"
#include "playerclass.h"
#include <string>

class Weapon : public Item {
public:
  std::string name;
  int HitMod;
  int damageType;
  int damageDie;
  int Number_DamageDice;
  int damageModifier;
  int weight;
  int onhitPoison;
  bool hasinInventory = false;

  void SetName(std::string nam) { name = nam; }
  void SetHitMod(int HitMo) { HitMod = HitMo; }
  void SetDamageType(int damageTyp) { damageType = damageTyp; }
  void SetDamageDie(int damageDi) { damageDie = damageDi; }
  void SetNumber_DamageDice(int Number_DamageDic) {
    Number_DamageDice = Number_DamageDic;
  }
  void SetonhitPoison(int ionhitPoison) { onhitPoison = ionhitPoison; }
  void SethasinInventory(bool is) { hasinInventory = is; }
  bool GethasinInventory() { return hasinInventory; }
  void SetdamageModifier(int damageModifie) { damageModifier = damageModifie; }
  void SetWeight(int weightset) { weight = weightset; }
  int getonhitPoison() { return onhitPoison; }
  int getHitMod() { return HitMod; }
  int getDamageType() { return damageType; }
  int getDamageDie() { return damageDie; }
  int getNumber_DamageDice() { return Number_DamageDice; }
  int getdamageModifier() { return damageModifier; }
  std::string getName() { return name; }
  int getWeight() { return weight; }

  virtual void Unlock(Weapon *weapon) { weapon->hasinInventory = true; }

  virtual void UpdatePoisonedBlade() {
    name = "Poisoned Blade";
    onhitPoison = 5;
    damageDie = 4;
    damageType = 2;
    damageModifier = 1;
    HitMod = 2;
    weight = 30;
    hasinInventory = false;
  }

  virtual void UpdateClub() {
    name = "Club";
    onhitPoison = 0;
    damageDie = 10;
    damageType = 2;
    damageModifier = 2;
    HitMod = 1;
    weight = 40;
    hasinInventory = false;
  }

  virtual void UpdateLongsword() {
    name = "Longsword";
    onhitPoison = 0;
    damageDie = 8;
    damageType = 2;
    damageModifier = 4;
    HitMod = 3;
    weight = 65;
    hasinInventory = false;
  }

  virtual void UpdateAdminStick() {
    name = "Admin Stick";
    onhitPoison = 0;
    damageDie = 10000;
    damageType = 1337;
    damageModifier = 10000;
    HitMod = 10000;
    hasinInventory = false;
  }

  void PrintStats() {
    std::cout << "Name: " << name << "\n";
    std::cout << "Hit Modifier: " << HitMod << "\n";
    std::cout << "Damage Type: " << damageType << "\n";
    std::cout << "Damage Die: " << damageDie << "\n";
    std::cout << "Damage Modifier: " << damageModifier << "\n";
    std::cout << "Weight: " << weight << "\n";
    std::cout << "Poison On Hit: " << onhitPoison << "\n";
  }
  Weapon() = default;
};

#endif