#ifndef GAMELOGICFUNCTIONS_H
#define GAMELOGICFUNCTIONS_H
#include <cstdlib>


int rollDie(int dieType, bool hasAdvantage, bool hasDisadvantage) {
  if (hasAdvantage == false && hasDisadvantage == false) {
    int x = rand() % dieType;
    return x;
  }
  if (hasAdvantage == true && hasDisadvantage == true) {
    int x = rand() % dieType;
    return x;
  }
  if (hasAdvantage == true && hasDisadvantage == false) {
    int x = rand() % dieType;
    int y = rand() % dieType;
    if (x >= y) {
      return x;
    } else {
      return y;
    }
  }
  if (hasAdvantage == false && hasDisadvantage == true) {
    int x = rand() % dieType;
    int y = rand() % dieType;
    if (x <= y) {
      return x;
    } else {
      return y;
    }
  } else {
    int x = rand() % dieType;
    return x;
  }
};


#endif