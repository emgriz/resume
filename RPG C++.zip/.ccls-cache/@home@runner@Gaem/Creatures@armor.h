#ifndef ARMOR_H
#define ARMOR_H
#include "armorclass.h"

class plateArmor : public Armor {
public:
  plateArmor() {
    setName("Plate Armor");
    setConstitution(5);
    setDexterity(5);
    setStrength(5);
    setHitPoints(5);
    setArmor(5);
    setWeight(50);
  }
};

class chainMail : public Armor {
public:
  chainMail() {
    setName("Chain Mail");
    setConstitution(0);
    setDexterity(4);
    setStrength(0);
    setHitPoints(5);
    setArmor(2);
    setWeight(30);
  }
};

class leatherArmor : public Armor {
public:
  leatherArmor() {
    setName("Leather Armor");
    setConstitution(2);
    setDexterity(2);
    setStrength(0);
    setHitPoints(2);
    setArmor(1);
    setWeight(20);
  }
};

class mithrilArmor : public Armor {
public:
  mithrilArmor() {
    setName("Mithril Armor");
    setConstitution(2);
    setDexterity(0);
    setStrength(4);
    setHitPoints(2);
    setArmor(2);
    setWeight(80);
  }
};

#endif