#ifndef GAMELOGICFUNCTION_H
#define GAMELOGICFUNCTION_H
#include <cstdlib>

class gameLogicFunctions {
public:
  int rollDie(int dieType, bool hasAdvantage, bool hasDisadvantage);
};

#endif