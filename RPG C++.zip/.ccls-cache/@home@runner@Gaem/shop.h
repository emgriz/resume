#include <iostream>
#include <string>
#include <vector>

#include "Creatures/armor.h"
#include "Creatures/inventory.h"
#include "Creatures/item.h"
#include "Creatures/rings.h"
#include "Creatures/weapons.h"

enum class ItemType { WEAPON, RING, ARMOR };

struct ShopItem {
  std::string name;
  int price;
  ItemType type;
  float weight;
};

class Shop {
public:
  void addItem(const std::string &name, int price, ItemType type,
               float weight) {
    items.push_back({name, price, type, weight});
  };

  void displayItems() const {
    std::cout << "Items available in the shop:" << std::endl;
    for (const auto &item : items) {
      std::cout << "Name: " << item.name << ", Price: " << item.price
                << ", Weight: " << item.weight << std::endl;
    }
  }

  bool purchaseItem(int index, Inventory &inventory) {
    if (index < 0 || index >= items.size()) {
      std::cout << "Invalid item index." << std::endl;
      return false;
    }
    ShopItem item = items[index];
    if (inventory.getGold() < item.price) {
      std::cout << "You don't have enough gold to purchase this item."
                << std::endl;
      return false;
    }
    if (inventory.getWeightCounter() + item.weight >
        inventory.getWeightLimit()) {
      std::cout << "That item is too heavy!" << std::endl;
      return false;
    }
    inventory.updateGold(-item.price);
    Item *newItem = new Item(item.name, item.weight);
    inventory.addItem(newItem);

    std::cout << "You purchased " << item.name << "." << std::endl;
    return true;
  };

  Shop() {}

private:
  std::vector<ShopItem> items;
};