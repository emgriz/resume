#ifndef STACK_H
#define STACK_H



#include <iostream>

class Node {
public:
int data;
Node* nextNode;
};

class Stack {
public:

Node* top;
int size;

void push(Node* newNode){
  if(top == NULL){
    top = newNode;
  }//end if
  else
  {
    newNode->nextNode = top;
    top = newNode;
  } //end else
}// end push

Node pop(){
    Node* temp = top;
    top = top->nextNode;
    return *temp;
  }//end pop

Node peek() {
  return *top;
} // end peek

bool isEmpty(){
  if (top == NULL){
    return true;
  }
  else {return false;}
} // end isEmpty



}; // end class Stack
int main() {
}



#endif