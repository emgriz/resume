#include "Creatures/weapons.h"
#include "Creatures/rings.h"
#include "Creatures/armor.h"
#include "Creatures/inventory.h"

class Shop {
public:
  


  Shop() {}


private:
}