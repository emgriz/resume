#ifndef RINGS_H
#define RINGS_H
#include "ringclass.h"

class goldRing : public Ring {
public:
  goldRing() {
    setName("Gold Ring");
    setIntelligence(5);
    setWisdom(5);
    setCharisma(5);
    setStrength(5);
    setWeight(5);
  }
};

class silverRing : public Ring {
public:
  silverRing() {
    setName("Silver Ring");
    setIntelligence(3);
    setWisdom(3);
    setCharisma(3);
    setStrength(3);
    setWeight(3);
  }
};

class bandedRing : public Ring {
public:
  bandedRing() {
    setName("Banded Ring");
    setIntelligence(2);
    setWisdom(2);
    setCharisma(2);
    setStrength(2);
    setWeight(2);
  }
};

#endif