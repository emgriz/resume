#include "creatureclass.h"
#include "monsters.h"
#include <iostream>
#include <string>
using namespace std;

class Map {
public:
  int numrows;
  int numcolumns;

  Creature *data;

  void printMap() {
    for (int i = 0; i < numrows; i++) {
      for (int j = 0; j < numcolumns; j++) {
        if (data == nullptr) {
          cout << "0";
        } else if (dynamic_cast < Player*>(data) != nullptr) {
          cout << "P";
        }
        if (dynamic_cast< Monster*>(data) != nullptr) {
          cout << "M";
        }
      }
    }
  }

  Creature *coorddata() {
    return data; // something
  }

  Map() = default;
  Map(int numrows, int numcolumns) {
    Creature *arrayOfArrays[numrows][numcolumns];
    for (int i = 0; i < numrows; i++) {
      for (int j = 0; j < numcolumns; j++) {
        arrayOfArrays[i][j] = nullptr;
      }
    }
  }
};