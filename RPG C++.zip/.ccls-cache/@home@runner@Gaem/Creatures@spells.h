#ifndef SPELLS_H
#define SPELLS_H

#include "gamelogicfunction.h"
#include "playerclass.h"
#include <string>

#include "monsters.h"
#include <unistd.h>

class Spell {
public:
  std::string name = "";
  int onhitPoison;
  int damageDie;
  std::string Type;
  int damageModifier;
  int HitMod;
  bool isAction;
  bool isReaction;
  int SpellSlot;
  Spell() = default;

  bool hasUnlocked;

  int getDamageDie() { return damageDie; }
  void setDamageDie(int die) { damageDie = die; }
  int getSpellSlot() { return SpellSlot; }
  void setSpellSlot(int slot) { SpellSlot = slot; }

  std::string getName() { return name; }
  void setName(std::string nam) { name = nam; }

  int getHitMod() { return HitMod; }
  void setHitMod(int mod) { HitMod = mod; }

  std::string getType() { return Type; }
  void setType(std::string type) { Type = type; }

  int getDamageModifier() { return damageModifier; }
  void setDamageModifier(int modifier) { damageModifier = modifier; }

  int getOnhitPoison() { return onhitPoison; }
  void setOnhitPoison(int poison) { onhitPoison = poison; }

  void setDamageType(std::string type) { Type = type; }

  virtual void Cast(Creature &player, Creature &target){};
};

class Fire_Bolt : public Spell {
public:
  std::string name = "Fire Bolt";
  int onhitPoison = 0;
  int damageDie = 10;
  int HitMod = 0;
  int SpellSlot = 0;
  std::string Type = "Fire";
  bool isAction = true;
  bool isReaction = false;
  Fire_Bolt(){
			name = "Fire Bolt";
			onhitPoison = 0;
			damageDie = 10;
			HitMod = 0;
			SpellSlot = 0;
			Type = "Fire";
			isAction = true;
			isReaction = false;
			}
  int getDamageDie() { return damageDie; }
  void setDamageDie(int die) { damageDie = die; }
  int getSpellSlot() { return SpellSlot; }
  void setSpellSlot(int slot) { SpellSlot = slot; }

  std::string getName() { return name; }
  void setName(std::string nam) { name = nam; }

  int getHitMod() { return HitMod; }
  void setHitMod(int mod) { HitMod = mod; }

  std::string getType() { return Type; }
  void setType(std::string type) { Type = type; }

  int getDamageModifier() { return damageModifier; }
  void setDamageModifier(int modifier) { damageModifier = modifier; }

  int getOnhitPoison() { return onhitPoison; }
  void setOnhitPoison(int poison) { onhitPoison = poison; }

  void setDamageType(std::string type) { Type = type; }

  void Cast(Creature &player, Creature &target) {
    std::cout << "You hurl a bolt of fire at " << target.GetName() << "..."
              << std::endl;
    sleep(1);
    gameLogicFunctions logic;
    int roll = logic.rollDie(20, false, false) + HitMod;
    if (roll > target.GetArmorClass()) {
      int damage = logic.rollDie(damageDie, false, false) + damageModifier;
      target.SetHitPoints(target.GetHitPoints() - damage);
      std::cout << "And hit " << target.GetName() << " for " << damage
                << "fire damage!" << std::endl;
    } else {
      std::cout << "And miss." << std::endl;
    }
  }
};

class Lightning_Bolt : public Spell{
public:
std::string name = "Lightning Bolt";
int onhitPoison = 0;
int damageDie = 30;
int damageModifier = 5;
int HitMod = 0;
int SpellSlot = 2;
std::string Type = "Lightning";
bool isAction = true;
bool isReaction = false;
Lightning_Bolt(){
	name = "Lightning Bolt";
	onhitPoison = 0;
	damageDie = 30;
	damageModifier = 5;
	HitMod = 0;
	SpellSlot = 2;
	Type = "Lightning";
	isAction = true;
	isReaction = false;
}
void Cast(Creature &player, Creature &target) {
		if (player.secondspellslots > 0) {
				std::cout << "You cast Lightning Bolt!" << std::endl;
				gameLogicFunctions logic;
				int damage = logic.rollDie(damageDie, false, false) + damageModifier;
				target.SetHitPoints(target.GetHitPoints() - damage);
				if (target.GetHitPoints() < 1) {
						std::cout << "You have killed " << target.GetName() << "!" << std::endl;
				}
				player.secondspellslots -= 1;
		}

		else {
				std::cout << "You have no more second level spell slots!" << std::endl;
		}

} // end Cast
}; // end Bolt

class Fiery_Rebuke : public Spell {
public:
  std::string name = "Fiery Rebuke";
  int onhitPoison = 0;
  int damageDie = 20;
  int HitMod = 0;
  int SpellSlot = 1;
  std::string Type = "Fire";
  bool isAction = false;
  bool isReaction = true;
  Fiery_Rebuke() {
    name = "Fiery Rebuke";
    onhitPoison = 0;
    damageDie = 20;
    HitMod = 0;
    SpellSlot = 1;
    Type = "Fire";
    isAction = false;
    isReaction = true;
  }
  int getDamageDie() { return damageDie; }
  void setDamageDie(int die) { damageDie = die; }
  int getSpellSlot() { return SpellSlot; }
  void setSpellSlot(int slot) { SpellSlot = slot; }

  std::string getName() { return name; }
  void setName(std::string nam) { name = nam; }

  int getHitMod() { return HitMod; }
  void setHitMod(int mod) { HitMod = mod; }

  std::string getType() { return Type; }
  void setType(std::string type) { Type = type; }

  int getDamageModifier() { return damageModifier; }
  void setDamageModifier(int modifier) { damageModifier = modifier; }

  int getOnhitPoison() { return onhitPoison; }
  void setOnhitPoison(int poison) { onhitPoison = poison; }

  void setDamageType(std::string type) { Type = type; }

  void Cast(Creature &player, Creature &target) {
    if (player.firstspellslots > 0) {
      std::cout << "You cast Fiery Rebuke!" << std::endl;
      // if target dies pop their attack off the stack
      gameLogicFunctions logic;
      int damage = logic.rollDie(damageDie, false, false) +
                   logic.rollDie(damageDie, false, false) + damageModifier;
      target.SetHitPoints(target.GetHitPoints() - damage);
      if (target.GetHitPoints() < 1) {
        std::cout << "You have killed " << target.GetName()
                  << ", preventing its attack on you!" << std::endl;
      }
      player.firstspellslots -= 1;
    }

    else {
      std::cout << "You have no more first level spell slots!" << std::endl;
    }

  } // end Cast

}; // end Class

#endif