#ifndef WEAPON_H
#define WEAPON_H


class Weapon : public Item {
public:
  int HitMod;
  int damageType; // slashing is 1, piercing is 2, bludgeoning is 3, and most
                  // magic is 4, for now
  int damageDie;
  int Number_DamageDice;
  int damageModifier;
  int getHitMod() { return HitMod; }
  int getDamageType() { return damageType; }
  int getDamageDie() { return damageDie; }
  int getNumber_DamageDice() { return Number_DamageDice; }
  int getdamageModifier() { return damageModifier; }
  void setHitMod(int HitMo) { HitMod = HitMo; }
  void setDamageType(int damageTyp) { damageType = damageTyp; }
  void setDamageDie(int damageDi) { damageDie = damageDi; }
  void setNumber_DamageDice(int Number_DamageDic) {
    Number_DamageDice = Number_DamageDic;
  }
  void setdamageModifier(int damageModifie) { damageModifier = damageModifie; }

  Weapon() = default;
};

#endif