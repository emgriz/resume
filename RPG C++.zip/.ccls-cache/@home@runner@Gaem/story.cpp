#include <iostream>
#include <sstream>
#include <string>
#include <unordered_map>

#include "./Creatures/dialogueTree.h"
#include "./Creatures/gamelogicfunction.h"
#include "./Creatures/monsters.h"
#include "testingcenter.h"

/*void closeMenu() { std::cout << "Menu Closed" << std::endl; } // option 1 DONE

void enterBattle() {
  std::cout << "You have entered battle" << std::endl;
  // START BATTLE SEQUENCE
} // option 2

void openInventory(const Inventory &inventory) {
  std::cout << "You have opened your inventory" << std::endl;
  inventory.printInventory();
} // option 3 DONE

void enterShop() {
  std::cout << "You have entered the shop" << std::endl;
  // IMPLEMENT SHOP
} // option 4

void chat() {
  std::cout << "You have started a dialogue" << std::endl;
} // option 5

void openMap() {
  std::cout << "You have opened the map" << std::endl;
} // option 6

void saveGame(const Player &player, const Inventory &inventory,
              const DialogueTree &dialogueTree) {
  ofstream file("save.txt", ios::out | ios::trunc);
  if (!file.is_open()) { // for debugging
    std::cout << "Error opening save file." << std::endl;
    return;
  }
  file << player.name << endl;
  file << player.constitution << endl;
  file << player.dexterity << endl;
  file << player.strength << endl;
  file << player.intelligence << endl;
  file << player.wisdom << endl;
  file << player.charisma << endl;
  file << player.hitPoints << endl;
  file << player.armorClass << endl;
  file << player.conmod << endl;
  file << player.dexmod << endl;
  file << player.strmod << endl;
  file << player.intmod << endl;
  file << player.wismod << endl;
  file << player.chamod << endl;
  file << player.IsProne << endl;
  file << player.HasAdvantage << endl;
  file << player.HasDisadvantage << endl;
  Inventory::inventoryNode *temp = inventory.head;
  while (temp != nullptr) {
    // when you save the game, the items in the inventory will be appended to
    // the save file with a prefix "ITEM:"
    file << "ITEM:" << temp->item->getName() << endl;
    temp = temp->nextItem;
  }
  Node *rootNode = dialogueTree.getRoot();
  if (rootNode != nullptr) {
    dialogueTree.saveDialogueTree(file, rootNode);
  }
  file.close();
} // option 7 DONE

void loadSavedGame(vector<string> &myVec, Player &Player, Inventory &inventory,
                   vector<Node> &dialogueTree) {
  ifstream file("save.txt");
  if (!file.is_open()) {
    std::cout << "Error opening save file." << std::endl;
    return;
  }
  string line;
  while (getline(file, line)) {
    if (line.find("ITEM:") != string::npos) {
      // when you load the saved game, the items will be extracted from the save
      // file and added back to the inventory.
      
    } else if (line.find("NODE:") != string::npos) {
      // when encountering a line indicating a serialized node, deserialize it
      // and add it to the dialogue tree
      std::string serializedNode = line.substr(5);
      dialogueTree.emplace_back(Node::deserialize(serializedNode));
    } else {
      myVec.push_back(line);
    }
  }
  //if (myVec.size() >= 14) {
    // sets the player's stats to the values in the vector of strings
    Player.name = myVec[0];
    // stoi function converts string to int value
    Player.constitution = stoi(myVec[1]);
    Player.dexterity = stoi(myVec[2]);
    Player.strength = stoi(myVec[3]);
    Player.intelligence = stoi(myVec[4]);
    Player.wisdom = stoi(myVec[5]);
    Player.charisma = stoi(myVec[6]);
    Player.hitPoints = stoi(myVec[7]);
    Player.armorClass = stoi(myVec[8]);
    Player.conmod = stoi(myVec[9]);
    Player.dexmod = stoi(myVec[10]);
    Player.strmod = stoi(myVec[11]);
    Player.intmod = stoi(myVec[12]);
    Player.wismod = stoi(myVec[13]);
    Player.chamod = stoi(myVec[14]);

    if (myVec.size() >= 15) {
      // sets the boolean values to 0 (for now, might change)
      Player.IsProne = (myVec[15] == "0");
      Player.HasAdvantage = (myVec[16] == "0");
      Player.HasDisadvantage = (myVec[17] == "0");
    }
  } else {
    std::cout << "Error. Data in save file cannot be loaded." << std::endl;
  }
} // option 8 DONE

void quitGame() {
  std::cout << "You have quit the game" << std::endl;
  abort();
} // option 9 DONE

void openMenu(const std::vector<std::string> &myVec, const Player &player,
              const Inventory &inventory, const DialogueTree &dialogueTree) {
  std::cout << "Menu:" << std::endl;
  std::cout << "1. Return to Game" << std::endl;
  std::cout << "2. Enter Battle" << std::endl;
  std::cout << "3. Open Inventory" << std::endl;
  std::cout << "4. Open Shop" << std::endl;
  std::cout << "5. Start Dialogue" << std::endl;
  std::cout << "6. Open Map" << std::endl;
  std::cout << "7. Save Game" << std::endl;
  std::cout << "8. Load Saved Game" << std::endl;
  std::cout << "9. Quit" << std::endl;
  while (true) {
    int choice;
    std::cout << "Enter your choice: ";
    std::cin >> choice;
    switch (choice) {
    case 1:
      closeMenu();
      break;
    case 2:
      enterBattle();
      break;
    case 3:
      openInventory(inventory);
      break;
    case 4:
      enterShop();
      break;
    case 5:
      chat();
      break;
    case 6:
      openMap();
      break;
    case 7:
      saveGame(player, inventory, dialogueTree);
      break;
    case 8:
      void loadSavedGame(vector<string>&myVec, Player &player, Inventory &inventory, vector<Node>&dialogueTree);
      break;
    case 9:
      quitGame();
      break;
    default:
      std::cout << "Invalid choice. Please choose again." << std::endl;
      break;
    }
  }
}
*/
int main() {
  srand(time(NULL));
  DialogueTree tree;

  Node *startNode = new Node(
      "Snow gently falls from the sky and wind bites your cheeks as you "
      "stand in the graveyard of Palebank Village, a fishing outpost of "
      "Uthodurn that is home to several hundred dwarves and  elves. The sun "
      "is low in the sky, sinking behind the fresh grave of Urgon Wenth, an "
      "old dwarf who caught a curse or disease that turned him into an ice "
      "statue. The folk of the village have gathered to pay their final "
      "respects to Urgon’s frozen remains. A gruff voice speaks softly from "
      "behind you. \" Thank you for attending Urgon’s service.\" You turn "
      "and meet the gaze of Elro Aldataur, a weathered elf, retired ranger, "
      "and the leader of the village. \" I’m sorry to speak of dark tidings "
      "under such circumstances, but I believe that Palebank Village might "
      "be in danger, and I’m hoping you can help us.\" \n\n"
      "1. Yes, I'll help\n"
      "2. No, I will not\n");

  Node *noNode = new Node("Please rethink your decision.\n"
                          "1. Yes, I will help\n"
                          "2. No, go back to start\n");

  Node *yesNode = new Node(
      "Two months ago, Urgon Wenth returned home from a year of exploration "
      "in Eiselcross, only to fall ill with a strange affliction that caused "
      "him to move slowly and develop blue veins all over his body. Despite "
      "efforts from the village's priests, Urgon's condition worsened until "
      "he eventually turned to ice. The community believed this was an "
      "isolated incident until Tulgi Lutan, a dwarf trapper, began showing "
      "similar symptoms. When Elro tried to talk to Tulgi about it, she "
      "asked to be left to die in peace. \n"
      "Help me find what caused this.\n"
      "1. Go to Tulgi's house\n"
      "2. Go to Urgon's cabin\n");

  tree.addNode(startNode, 1, yesNode);
  tree.addNode(startNode, 2, noNode);
  tree.addNode(noNode, 1, yesNode);
  tree.addNode(noNode, 2, startNode);

  Node *tulgisHouseNode = new Node(
      "This snow-covered cabin looks peaceful and quiet from the outside. "
      "Its windows are shuttered, and a steady stream of smoke piping out of "
      "the chimney indicates a roaring fire within.\n"
      "1. Break into Tulgi's house\n"
      "2. Knock on the door\n");

  tree.addNode(yesNode, 1, tulgisHouseNode);

  Node *breakInNode = new Node("How would you like to do that?\n"
                               "1. Attack the door\n"
                               "2. Pick the lock\n"
                               "3. Unlatch the window\n"
                               "4. Force the door open\n");

  tree.addNode(tulgisHouseNode, 1, breakInNode);

  Node *attackDoorNode = new Node("You attack the door and break it down.\n"
                                  "1. Enter the cabin\n");

  tree.addNode(breakInNode, 1, attackDoorNode);

  Node *pickLockNode = new Node("You pick the lock and enter the cabin.\n"
                                "1. Enter the cabin\n");

  tree.addNode(breakInNode, 2, pickLockNode);

  Node *unlatchWindowNode =
      new Node("You unlatch the window and climb in.\n"
               // DC 12 Dexterity check using thieves tools.
               "1. Enter the cabin\n");

  tree.addNode(breakInNode, 3, unlatchWindowNode);

  Node *forceDoorNode =
      new Node("You force the door open and enter the cabin.\n"
               // DC 15 strength (Athletics)
               "1. Enter the cabin\n");

  tree.addNode(breakInNode, 4, forceDoorNode);

  Node *knockOnDoorNode =
      new Node("You knock on the door. From somewhere inside the house you "
               "hear Tulgi tell you to go away.\n"
               "1. Shout back to tulgi\n");

  tree.addNode(tulgisHouseNode, 2, knockOnDoorNode);

  Node *shoutBackToTulgiNode = new Node("You shout back to Tulgi.\n"
                                        // successful DC 12 Charisma (deception,
                                        // intimidation, or persuasion) checkn"
                                        "1. Enter Tulgi's house\n");

  tree.addNode(knockOnDoorNode, 1, shoutBackToTulgiNode);

  Node *forceIntoTulgisHouseNode =
      new Node("You enter Tulgi's house. Tulgi sees you and immediately "
               "attacks with her wolves.\n",
               true, "1. force Tulgi to talk\n", 3, new Guard(), "Tulgi",
               new Wolf(), "Fido", new Wolf(), "Hairy");

  tree.addNode(attackDoorNode, 1, forceIntoTulgisHouseNode);
  tree.addNode(pickLockNode, 1, forceIntoTulgisHouseNode);
  tree.addNode(unlatchWindowNode, 1, forceIntoTulgisHouseNode);
  tree.addNode(forceDoorNode, 1, forceIntoTulgisHouseNode);

  Node *forceTulgiToTalkNode = new Node(
      "You force Tulgi to talk. She tells you the following:\n"
      "\"I came to Palebank Village a few years ago from Shadycreek Run with "
      "my sister, Hulil. We both work for the Uttolot family. The Uttolots "
      "sent us and a few others to the village to keep an eye on treasures "
      "coming back from Eiselcross, with the intent of stealing them. When "
      "such artifacts come through the small settlement, they are often "
      "unusual goods that treasure hunters are trying to keep away from "
      "Uthodurn or the Dwendalian Empire. When Urgon Wenth returned to "
      "Palebank Village with treasures from Eiselcross, I saw my chance. I "
      "waited for Urgon to sell his finds to Pelc’s Curiosities, then stole "
      "them all. I gave most of Urgon’s relics to Hulil, but kept one for "
      "myself—an ornate dagger. Hulil has the other items in a site north of "
      "the village known as Croaker Cave. I was the one who searched Urgon’s "
      "cabin, convinced that the dead dwarf must have had magic or other "
      "secrets stored away there.\n"
      "1. Go to Croaker Cave\n"
      "2. Go to Urgon's Cabin\n"
      "3. Go to Pelc's Curiosities\n");

  tree.addNode(forceIntoTulgisHouseNode, 1, forceTulgiToTalkNode);

  Node *enterTulgisHouseNode = new Node(
      "The heat in this small cabin hits like a hammer blow. A table set "
      "with neatly stacked dishes, tools, and utensils stands at the center "
      "of the room. The smell of a simmering soup comes from a pot hanging "
      "inside a roaring fireplace. Another fire burns in an iron brazier at "
      "the opposite end of the room, filling the cabin with a smoky haze. "
      "Shivering at the end of a bed near the brazier is a dwarf wrapped in "
      "blankets. Bulging blue veins streak her face, neck, and hands.\n"
      "1. Talk to Tulgi\n");

  tree.addNode(shoutBackToTulgiNode, 1, enterTulgisHouseNode);

  Node *talkToTulgiNode = new Node(
      "\"I came to Palebank Village a few years ago from Shadycreek Run with "
      "my sister, Hulil. We both work for the Uttolot family. The Uttolots "
      "sent us and a few others to the village to keep an eye on treasures "
      "coming back from Eiselcross, with the intent of stealing them. When "
      "such artifacts come through the small settlement, they are often "
      "unusual goods that treasure hunters are trying to keep away from "
      "Uthodurn or the Dwendalian Empire. When Urgon Wenth returned to "
      "Palebank Village with treasures from Eiselcross, I saw my chance. I "
      "waited for Urgon to sell his finds to Pelc’s Curiosities, then stole "
      "them all. I gave most of Urgon’s relics to Hulil, but kept one for "
      "myself—an ornate dagger.\" Hulil has the other items in a site north "
      "of the village known as Croaker Cave. I was the one who searched "
      "Urgon’s cabin, convinced that the dead dwarf must have had magic or "
      "other secrets stored away there.\n"
      "1. Go to Croaker Cave\n"
      "2. Go to Urgon's Cabin\n"
      "3. Go to Pelc's Curiosities\n");

  tree.addNode(enterTulgisHouseNode, 1, talkToTulgiNode);

  Node *urgonCabinNode =
      new Node("Urgon Wenth's cabin is a one-story, one-room log cabin at "
               "the edge of town. A good-natured wood elf named Mila Teno "
               "stands guard outside the front door.\n"
               "1. Explain to Mila why you are there\n"
               "2. Attack Mila\n");

  tree.addNode(talkToTulgiNode, 2, urgonCabinNode);
  tree.addNode(yesNode, 2, urgonCabinNode);
  tree.addNode(forceTulgiToTalkNode, 2, urgonCabinNode);

  Node *attackMilaNode =
      new Node("You attack Mila.\n", true, "1. Enter Urgon's cabin\n", 1,
               new Scout(), "Mila");

  tree.addNode(urgonCabinNode, 2, attackMilaNode);

  Node *explainToMilaNode =
      new Node("You explain to Mila that you have been sent on a mission to "
               "find the cure for an illness that has been affecting the "
               "village. You explain that you need to go inside the cabin to "
               "find clues about this illness and its cure.\n"
               "1. Enter Urgon's cabin\n");

  tree.addNode(urgonCabinNode, 1, explainToMilaNode);

  Node *enterUrgonsCabinNode = new Node(
      "You enter Urgon Wenth's cabin. This cramped, dark cabin might have "
      "been a cozy place when its owner was alive. Now an unmade bed stands "
      "near a cold fireplace, its mantle hung with the head of some snarling "
      "white beast with gray horns. On the other side of the room, a small "
      "table strewn with dirty dishes and set with a dwarf-sized chair "
      "stands before two empty shelves whose contents are scattered across "
      "the floor: kitchen utensils, dried foodstuffs, adventuring gear, and "
      "a few books.\n"
      "1. Search the bookshelf\n"
      "2. Search the mess\n");

  tree.addNode(attackMilaNode, 1, enterUrgonsCabinNode);
  tree.addNode(explainToMilaNode, 1, enterUrgonsCabinNode);

  Node *searchBookshelfNode = new Node(
      "You search the bookshelf. You find a recipt being used as a bookmark. "
      "It is dated two months ago and indicates Urgon sold several Aeorian "
      "items from Eiselcross to a local antique shop, Pelc's Curiosities, "
      "for 1000 gold pieces. Listed on the recipt are: a dagger, a scroll "
      "case, a jade statuette, a quiver of 20 arrows, a silver ring set with "
      "jasper, and two blue glass vials\n"
      "1. Go to Pelc's Curiosities\n"
      "2. Go to Tulgi's House\n"
      "3. Search the mess\n");

  tree.addNode(enterUrgonsCabinNode, 1, searchBookshelfNode);
  tree.addNode(searchBookshelfNode, 2, enterTulgisHouseNode);

  Node *searchThroughTheMessNode = new Node(
      "It appears as though someone recently trashed the cabin while "
      "searching it. You see footprints belonging to Tulgi Lutan, a dwarf "
      "desperate to find any clues that might help her cure the disease that "
      "is killing her. The tracks lead out the front door.\n"
      "1. Go to Tulgi's House\n"
      "2. Go to Pelc's Curiosities\n"
      "3. Search the bookshelf\n");

  tree.addNode(enterUrgonsCabinNode, 2, searchThroughTheMessNode);
  tree.addNode(searchThroughTheMessNode, 3, searchBookshelfNode);
  tree.addNode(searchBookshelfNode, 3, searchThroughTheMessNode);
  tree.addNode(searchThroughTheMessNode, 1, enterTulgisHouseNode);

  Node *goToPelcsCuriositiesNode =
      new Node("The dark cabin before you has a sign over its door which "
               "reads, “Pelc’s Curiosities,” with the image of a curving "
               "dragon used to make the letter P. Though the shop appears "
               "closed, the front door is slightly ajar.\n"
               "1. Open the front door\n"
               "2. Enter the back room through the shutters\n");

  tree.addNode(searchBookshelfNode, 1, goToPelcsCuriositiesNode);
  tree.addNode(searchThroughTheMessNode, 2, goToPelcsCuriositiesNode);
  tree.addNode(talkToTulgiNode, 3, goToPelcsCuriositiesNode);
  tree.addNode(forceTulgiToTalkNode, 3, goToPelcsCuriositiesNode);

  Node *goThroughTheFrontDoorNode = new Node(
      "You open the front door. Five cloaked elves appear to have ransacked "
      "the shop and are searching through the broken debris on the floor. "
      "The furniture, shelves, and front counter have been smashed, and the "
      "shop’s wares now litter the floor.\n"
      "1. Question the bandits\n"
      "2. Surrender to the bandits\n"
      "3. Attack the bandits\n");

  tree.addNode(goToPelcsCuriositiesNode, 1, goThroughTheFrontDoorNode);

  Node *questionTheBanditsNode = new Node(
      "You question the bandits. You find out that Hulil Lutan is a dwarf "
      "priestess of Tiamat. She employs a group of bandits who work for the "
      "Uttolot family in Shadycreek Run. Hulil's sister, Tulgi, recently "
      "robbed Pelc's Curiosities. Hulil is afflicted with an illness or "
      "curse that is turning her veins blue and causing her to move slowly. "
      "In an effort to find a cure, Hulil ordered her bandits to search "
      "Pelc's Curiosities for potions, scrolls, or other items. However, "
      "their search yielded nothing useful. Hulil is currently hiding out "
      "with more bandits in Croaker Cave.\n"
      // DC 10 Charisma (intimidation) check
      "1. Go to Croaker Cave\n"
      "2. Go into the back room where Verla Pelc is\n");

  tree.addNode(goThroughTheFrontDoorNode, 1, questionTheBanditsNode);

  Node *surrenderToTheBanditsNode =
      new Node("You surrender to the bandits.\n"
               "1. Question the bandits\n"
               "2. Leave Pelc's Curiosities and go to Croaker Cave\n");

  tree.addNode(goThroughTheFrontDoorNode, 2, surrenderToTheBanditsNode);
  tree.addNode(surrenderToTheBanditsNode, 1, questionTheBanditsNode);

  Node *attackTheBanditsNode = new Node(
      "You attack the bandits.\n", true, "1. Question the bandits\n", 5,
      new Bandit(), "Bandit 1", new Bandit(), "Bandit 2", new Bandit(),
      "Bandit 3", new Bandit(), "Bandit 4", new Bandit(), "Bandit 5");

  tree.addNode(goThroughTheFrontDoorNode, 3, attackTheBanditsNode);
  tree.addNode(attackTheBanditsNode, 1, questionTheBanditsNode);

  Node *enterThroughShuttersNode =
      new Node("You enter the back room through the shutters.\n"
               "1. Search the room\n");

  tree.addNode(goToPelcsCuriositiesNode, 2, enterThroughShuttersNode);

  Node *enterTheBackRoomNode =
      new Node("What appears to be an ice statue of an elf is bundled "
               "beneath the blankets of a bed along the east wall of the "
               "room. A small table loaded with dirty teacups and a kettle "
               "stands next to the bed. The frozen elf is Verla Pelc.\n"
               "1. Talk to Verla Pelc\n"
               "2. Go to Croaker Cave\n");

  tree.addNode(questionTheBanditsNode, 2, enterTheBackRoomNode);
  tree.addNode(enterThroughShuttersNode, 1, enterTheBackRoomNode);

  Node *talkToVerlaPelcNode = new Node(
      "You find out that Verla's symptoms appeared about two weeks ago after "
      "her shop was robbed. She asks you to find the cure for her illness.\n"
      "1. Go to Croaker Cave\n");

  tree.addNode(enterTheBackRoomNode, 1, talkToVerlaPelcNode);

  Node *CroakerCaveEntranceNode =
      new Node("You enter Croaker Cave. The slow dripping of water sounds "
               "out where it falls from stalactites down into a murky pool "
               "that fills the rough tunnel ahead. Every few moments, a loud "
               "croaking sounds out from somewhere in the darkness beyond. "
               "There is a 25-foot-long wooden beam lying against the wall.\n"
               "1. Go to the right\n" // training pool
               "2. Go to the left\n"  // bat cave
               "3. Look into the pool\n");

  tree.addNode(talkToVerlaPelcNode, 1, CroakerCaveEntranceNode);
  tree.addNode(enterTheBackRoomNode, 2, CroakerCaveEntranceNode);
  tree.addNode(surrenderToTheBanditsNode, 2, CroakerCaveEntranceNode);
  tree.addNode(questionTheBanditsNode, 1, CroakerCaveEntranceNode);
  tree.addNode(talkToTulgiNode, 1, CroakerCaveEntranceNode);
  tree.addNode(forceTulgiToTalkNode, 1, CroakerCaveEntranceNode);
  tree.addNode(enterTheBackRoomNode, 2, CroakerCaveEntranceNode);
  // check to make sure all connections are good

  Node *lookIntoThePoolNode =
      new Node("You look into the pool. You see two giant ice frogs.\n");
  // two giant ice frogs & three bandits

  tree.addNode(CroakerCaveEntranceNode, 3, lookIntoThePoolNode);

  Node *attackTheFrogsNode =
      new Node("You attack the frogs.\n", true,
               "1. Go to the right\n"
               "2. Go to the left\n",
               5, new GiantFrog(), "Giant Frog 1", new GiantFrog(),
               "Giant Frog 2", new Bandit(), "Bandit 1", new Bandit(),
               "Bandit 2", new Bandit(), "Bandit 3");

  tree.addNode(lookIntoThePoolNode, 1, attackTheFrogsNode);

  Node *batCaveNode = new Node(
      "You go to the left.This cavern reeks, and its floor is covered in bat "
      "guan A swarm of bats is sleeping in the rafters.\n"
      "1. Go straight\n" // bandit camp
      "2. Go back\n");   // croaker cave entrance

  tree.addNode(CroakerCaveEntranceNode, 2, batCaveNode);
  tree.addNode(batCaveNode, 2, CroakerCaveEntranceNode);
  tree.addNode(attackTheFrogsNode, 2, batCaveNode);

  Node *trainingPoolNode = new Node(
      "The slow dripping of water from the ceiling flows to a pool in the "
      "southwest corner of this cavern. A large wooden bucket with a lid "
      "sits near the edge of the pool. A dwarf and two elves bundled in "
      "layers of winter clothing are throwing dead bats into the air. Two "
      "giant blue-skinned frogs leap up to snatch the bats in midair, "
      "seemingly as part of some sort of training session.\n"
      "1. Go back\n"                     // croaker cave entrance
      "2. Continue through the cave\n"); // bandit camp

  tree.addNode(CroakerCaveEntranceNode, 1, trainingPoolNode);
  tree.addNode(trainingPoolNode, 1, CroakerCaveEntranceNode);
  tree.addNode(attackTheFrogsNode, 1, trainingPoolNode);

  Node *banditCampNode = new Node(
      "Ten empty bedrolls are arranged in a circle around a cold fire pit at "
      "the center of this cavern. Chicken bones, empty wine and spirits "
      "bottles, and other food waste litters the floor.\n"
      "1. Search the bedrolls\n"          // find 25 gold pieces
      "2. Go back to the training pool\n" // training pool
      "3. Go back to the bat cave\n"      // bat cave
      "4. Continue through the cave\n");  // croakers pond

  tree.addNode(batCaveNode, 1, banditCampNode);
  tree.addNode(trainingPoolNode, 2, banditCampNode);
  tree.addNode(banditCampNode, 2, trainingPoolNode);
  tree.addNode(banditCampNode, 3, batCaveNode);

  Node *searchBedrollsNode =
      new Node("You search the bedrolls and find 25 gold pieces.\n"
               "1. Go back to the training pool\n"
               "2. Go back to the bat cave\n"
               "3. Continue through the cave\n" // croakers pond
      );

  tree.addNode(banditCampNode, 1, searchBedrollsNode);
  tree.addNode(searchBedrollsNode, 1, trainingPoolNode);
  tree.addNode(searchBedrollsNode, 2, batCaveNode);

  Node *oldCroakersPondNode =
      new Node("Water dripping down from stalactites in the ceiling fills a "
               "dark pool that completely covers the floor of this "
               "cavern.You notice the largest ice frog you have ever seen.\n"
               "1. Convince old croaker to take you across the pool\n"
               "2. Go back to the bandit camp\n"); // bandit camp

  tree.addNode(banditCampNode, 4, oldCroakersPondNode);
  tree.addNode(searchBedrollsNode, 3, oldCroakersPondNode);
  tree.addNode(oldCroakersPondNode, 2, banditCampNode);

  Node *convinceOldCroakerNode = new Node(
      "Old Croaker ferries you and your party across the pool one at a time\n"
      "1. Fight old croaker\n"
      "2. Enter Hulil's cavern\n");

  tree.addNode(oldCroakersPondNode, 2, convinceOldCroakerNode);

  Node *fightOldCroakerNode =
      new Node("You are attacked by a giant frog, it is larger than all the "
               "other frogs you have encountered.\n",
               true, "1. Continue to Hulil's cavern\n", 1, new OldCroaker(),
               "Old Croaker");
  // giant toad with immunity to cold damage

  tree.addNode(convinceOldCroakerNode, 1, fightOldCroakerNode);

  Node *hulilsCavernNode = new Node(
      "A warm rush of heat comes from a massive fire burning in the center "
      "of this cavern, its smoke venting up through a narrow stone chimney. "
      "The flames illuminate a rough painting of a five-headed dragon that "
      "dominates the north wall. A bedroll is spread out beneath the mural. "
      "Near the crackling blaze, a dwarf bundled in a heavy cloak sits on a "
      "stone chest beside an elf whose face is covered in dragon tattoos. "
      "The dwarf’s face is streaked with pulsing blue veins.\n"
      "1. Attack Hulil\n"
      "2. Convince Hulil you are there to help her\n"
      "3. Go back to old croaker's pond\n");

  tree.addNode(hulilsCavernNode, 3, oldCroakersPondNode);
  tree.addNode(convinceOldCroakerNode, 2, hulilsCavernNode);
  tree.addNode(fightOldCroakerNode, 1, hulilsCavernNode);

  Node *hulilsAlliesNode = new Node(
      "Hulil believes she has a disease called frigid woe, which she "
      "suspects was caused by a cracked blue vial stolen by her sister, "
      "Tulgi, from Pelc's Curiosities. She has heard rumors that explorers "
      "in Eiselcross sometimes succumb to this disease. Desperate to find a "
      "cure, Hulil plans to trade the goods stolen by Tulgi in Shadycreek "
      "Run for a cure. She used one of the vials to trap stolen items in a "
      "chest and sold the other vial to Irven Liel, a human merchant staying "
      "at the Jolly Dwarf inn in Palebank Village.\n"
      "1. Go back to old croaker's pond\n"
      "2. Attack Hulil\n"
      "3. Go to the chest\n");

  tree.addNode(hulilsCavernNode, 2, hulilsAlliesNode);
  tree.addNode(hulilsAlliesNode, 1, oldCroakersPondNode);

  Node *attackHulilNode =
      new Node("You attack Hulil.\n", true, "1. Look around the cavern\n", 2,
               new Cult_Fanatic(), "Hulil", new Cultist(), "Raegrin");

  tree.addNode(hulilsCavernNode, 1, attackHulilNode);
  tree.addNode(hulilsAlliesNode, 2, attackHulilNode);

  Node *lookAroundTheCavernNode =
      new Node("You look around the cavern and notice a stone chest.\n"
               "1. Go to the chest\n");

  Node *goToChestNode = new Node("You see a stone chest whose outer lid is "
                                 "carved with the face of a dragon.\n"
                                 "1. Examine the chest\n"
                                 "2. Detect magic in the chest\n");

  tree.addNode(hulilsAlliesNode, 3, goToChestNode);
  tree.addNode(lookAroundTheCavernNode, 1, goToChestNode);

  Node *examineChestNode =
      new Node("There are pin-sized openings in the dragon's mouth that "
               "contain a blue powder.\n"
               "1. Use thieves tools to remove the powder\n"
               "2. Detect magic in the chest\n"
               "3. Open the chest\n" // successful DC 11 constitution save to
                                     // not get frigid woe
      );

  tree.addNode(goToChestNode, 1, examineChestNode);

  Node *detectMagicInChestNode =
      new Node("You detect an aura of evocation magic from the chest. If you "
               "attempt to open the chest without praying to Tiamet, wind "
               "blows from the dragon's mouth\n"
               "1. Pray to Tiamet\n"
               "2. Open Chest\n" // successful DC 11 constitution save to not
                                 // get frigid woe
               "3. Return to Hulil's cavern\n");

  tree.addNode(goToChestNode, 2, detectMagicInChestNode);
  tree.addNode(examineChestNode, 2, detectMagicInChestNode);

  Node *removePowderNode =
      new Node("You remove the powder from the dragon's mouth. The dragon "
               "can no longer infect you with frigid woe\n."
               "1. Open the chest\n");

  // add open chest choice and connection
  tree.addNode(examineChestNode, 1, removePowderNode);

  Node *prayToTiametNode = new Node(
      "You pray to Tiamet. When you go to open the chest, the powder will "
      "not blow into the room and you will not be infected.\n"
      "1. Open the chest\n");

  // add open chest choice and connection
  tree.addNode(detectMagicInChestNode, 1, prayToTiametNode);

  Node *openChestNode =
      new Node("You open the chest. The powder blows into the air. You are "
               "infected with frigid woe.\n");

  tree.addNode(detectMagicInChestNode, 2, openChestNode);
  tree.addNode(examineChestNode, 3, openChestNode);
  
  Node* safelyOpenChestNode = new Node("You safely open the chest. Inside you find the cure for frigid woe.\n"
  "1.Return to start\n"
  "2. End story\n");

  tree.addNode(prayToTiametNode, 1, safelyOpenChestNode);
  tree.addNode(removePowderNode,1, safelyOpenChestNode);
  tree.addNode(safelyOpenChestNode, 1, startNode);

  Node* endNode = new Node("You save Palebank Village.");

  tree.addNode(safelyOpenChestNode, 2, endNode);
  
  tree.setRoot(startNode);
  

  Node *current = tree.getRoot();

  while (current) {
    cout << current->text;
			sleep(5);
    if (current->hasEncounter) {
      current->RunEncounter(
          current, current->nummonsters, current->monster1, current->name1,
          current->monster2, current->name2, current->monster3, current->name3,
          current->monster4, current->name4, current->monster5, current->name5,
          current->monster6, current->name6, current->monster7, current->name7,
          current->monster8, current->name8);
      cout << current->choicetext;
    }
    int choice;
    cin >> choice;
    if (current->options.find(choice) != current->options.end()) {
      current = current->options[choice];
    } else {
      cout << "Invalid choice. Please try again.\n";
    }
    if (bool hasEncounter = false) {
      cout << "no encounter";
    } else if (bool hasEncounter = true) {
      cout << "\n\n";
    }
  }
  return 0;
};