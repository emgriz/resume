#ifndef MONSTERCLASS_H
#define MONSTERCLASS_H
#include "creatureclass.h"
#include <string>

class Monster : public Creature {
public:
  double CR;
  int XPvalue;
  std::string name;

  Monster() : Creature() {
    CR = 0;
    XPvalue = 0;
  };
};

#endif