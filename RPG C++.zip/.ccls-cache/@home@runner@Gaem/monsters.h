#ifndef MONSTERS_H
#define MONSTERS_H
#include "gamelogicfunction.h"
#include "monsterclass.h"
#include <string>

class Wolf : public Monster {
public:
  Wolf() : Monster() {
    name = "Wolf";
    strength = 12;
    dexterity = 15;
    constitution = 12;
    intelligence = 3;
    wisdom = 12;
    charisma = 6;
    hitPoints = 11;
    armorClass = 13;
    strmod = 1;
    dexmod = 2;
    conmod = 1;
    intmod = -4;
    wismod = 1;
    chamod = -2;
  };

  void Bite(Creature target) {
    int r = rollDie(20, false, false) + 4;
    if (r > target.GetArmorClass()) {
      int damage = rollDie(4, false, false) + rollDie(4, false, false) + 2;
      target.SetHitPoints(GetHitPoints() - damage);
      if ((rollDie(20, false, false) + target.GetStrmod()) <
          11) { // target gets IsProne = true}
      }
    }

  }; // Giant Frog
};   // Giant Frog

class Guard : public Monster {
public:
  std::string name;
  Guard() : Monster() {
    name = "Guard";
    strength = 13;
    dexterity = 12;
    constitution = 12;
    intelligence = 10;
    wisdom = 11;
    charisma = 10;
    hitPoints = 11;
    armorClass = 16;
    strmod = 1;
    dexmod = 1;
    conmod = 1;
    intmod = 0;
    wismod = 0;
    chamod = 0;
  }

  void Spear(Creature target) {
    int r = rollDie(20, false, false) + 3;
    if (r > target.GetArmorClass()) {
      int damage = rollDie(8, false, false) + 1;
      target.SetHitPoints(target.GetHitPoints() - damage);
    }
  }
};

class Noble : public Monster {
public:
  Noble() : Monster() {
    name = "Noble";
    strength = 11;
    dexterity = 12;
    constitution = 11;
    intelligence = 12;
    wisdom = 14;
    charisma = 16;
    hitPoints = 9;
    armorClass = 15;
    strmod = 0;
    dexmod = 1;
    conmod = 0;
    intmod = 1;
    wismod = 2;
    chamod = 3;
  }

  void Rapier(Creature target) {
    int r = rollDie(20, false, false) + 3;
    if (r > target.GetArmorClass()) {
      int damage = rollDie(8, false, false) + 1;
      target.SetHitPoints(target.GetHitPoints() - damage);
    }
  };
};

class Hobgoblin : public Monster {
public:
  Hobgoblin() : Monster() {
    name = "Hobgoblin";
    strength = 13;
    dexterity = 12;
    constitution = 12;
    intelligence = 10;
    wisdom = 10;
    charisma = 9;
    hitPoints = 11;
    armorClass = 18;
    strmod = 1;
    dexmod = 1;
    conmod = 1;
    intmod = 0;
    wismod = 0;
    chamod = -1;
  }

  void Longsword(Creature target) {
    int r = rollDie(20, false, false) + 3;
    if (r > target.GetArmorClass()) {
      int damage = rollDie(10, false, false) + 1;
      target.SetHitPoints(target.GetHitPoints() - damage);
    }
  };

  void Longbow(Creature target) {
    int r = rollDie(20, false, false) + 3;
    if (r > target.GetArmorClass()) {
      int damage = rollDie(8, false, false) + 1;
      target.SetHitPoints(target.GetHitPoints() - damage);
    }
  };
};

class adultRedDragon : public Monster {
public:
  int legendaryAction;
  adultRedDragon() : Monster() {
    name = "Adult Red Dragon";
    strength = 27;
    dexterity = 10;
    constitution = 25;
    intelligence = 16;
    wisdom = 13;
    charisma = 21;
    hitPoints = 256;
    armorClass = 19;
    strmod = 8;
    dexmod = 0;
    conmod = 7;
    intmod = 3;
    wismod = 1;
    chamod = 5;
    legendaryAction = 3;
  }

  void Dragon_Bite(Creature target) {
    int r = rollDie(20, false, false) + 14;
    if (r > target.GetArmorClass()) {
      int damage = rollDie(10, false, false) + rollDie(10, false, false) + 8;
      target.SetHitPoints(target.GetHitPoints() - damage);
      if ((rollDie(20, false, false) + target.GetStrmod()) < 11) {
        // isFrightened=true;
      }
    }
  };

  void ClawD(Creature target) {
    int r = rollDie(20, false, false) + 14;
    if (r > target.GetArmorClass()) {
      int damage = rollDie(6, false, false) + rollDie(6, false, false) + 8;
      target.SetHitPoints(target.GetHitPoints() - damage);
      if ((rollDie(20, false, false) + target.GetStrmod()) < 11) {
        // isFrightened=true;
      }
    }
  };

  void Tail(Creature target) {
    int r = rollDie(20, false, false) + 14;
    if (r > target.GetArmorClass()) {
      int damage = rollDie(8, false, false) + rollDie(8, false, false) + 8;
      target.SetHitPoints(target.GetHitPoints() - damage);
      if ((rollDie(20, false, false) + target.GetStrmod()) < 11) {
        // isFrightened=true;
      }
    }
  };

  void fireBreath(Creature target) {
    int sum = rollDie(6, false, false);
    for (int i = 0; i < 19; i++) {
      rollDie(6, false, false);
    }
    int damage = sum;
    if (rollDie(20, false, false) + target.GetDexmod() < 21) {
      target.SetHitPoints(target.GetHitPoints() - damage);
    } else {
      target.SetHitPoints(target.GetHitPoints() - (damage / 2));
    }
  };

  void multiAttack(Creature target) {
    // is frightened = true/false
    Dragon_Bite(target);
    ClawD(target);
    Dragon_Bite(target);
  };

  void wingAttack(Creature target) { /*attacks all creatures in 10 foot radius &
                                        costs 2 actions*/
    if (legendaryAction >= 2) {
      legendaryAction = legendaryAction - 2;
      int damage = rollDie(6, false, false) + rollDie(6, false, false) + 8;
      if (rollDie(20, false, false) + target.GetDexmod() < 22) {
        target.SetHitPoints(target.GetHitPoints() - damage);
        /*target gets IsProne = true*/
      } else {
        target.SetHitPoints(target.GetHitPoints() - (damage) / 2);
      }
    } else {
      std::cout << "You do not have enough actions to perform this action";
    }
    // wing attack is legendary and takes 2 actions
  };

  void tailAttack(Creature target) { /*attacks all creatures in 10 foot radius*/
    if (legendaryAction >= 1) {
      legendaryAction = legendaryAction - 1;
      int r = rollDie(20, false, false) + 14;
      if (r > target.GetArmorClass()) {
        int damage = rollDie(8, false, false) + rollDie(8, false, false) + 8;
        target.SetHitPoints(target.GetHitPoints() - damage);
        if ((rollDie(20, false, false) + target.GetStrmod()) < 11) {
          // isFrightened=true;
        }
      }
    } else {
      std::cout << "You do not have enough actions to perform this action";
    }
  };
  // detect
};

class Bugbear : public Monster {
public:
  Bugbear() : Monster() {
    name = "Bugbear";
    strength = 15;
    dexterity = 14;
    constitution = 13;
    intelligence = 8;
    wisdom = 11;
    charisma = 9;
    hitPoints = 27;
    armorClass = 16;
    strmod = 2;
    dexmod = 2;
    conmod = 1;
    intmod = -1;
    wismod = 0;
    chamod = -1;
  };

  void Morning_Star(Creature target) {
    int r = rollDie(20, false, false) + 4;
    if (r > target.GetArmorClass()) {
      int damage = rollDie(8, false, false) + rollDie(8, false, false) + 2;
      target.SetHitPoints(target.GetHitPoints() - damage);
    }
  };

  void Javelin(Creature target) {
    int r = rollDie(20, false, false) + 4;
    if (r > target.GetArmorClass()) {
      int damage = rollDie(6, false, false) + rollDie(6, false, false) + 2;
      target.SetHitPoints(target.GetHitPoints() - damage);
    }
  };
};

class GiantFrog : public Monster {
public:
  GiantFrog() : Monster() {
    name = "Giant Frog";
    strength = 12;
    dexterity = 13;
    constitution = 11;
    intelligence = 2;
    wisdom = 10;
    charisma = 3;
    hitPoints = 18;
    armorClass = 11;
    strmod = 1;
    dexmod = 1;
    conmod = 0;
    intmod = -4;
    wismod = 0;
    chamod = -4;
  };

  void Frog_Bite(Creature target) {
    int r = rollDie(20, false, false) + 3;
    if (r > target.GetArmorClass()) {
      int damage = rollDie(6, false, false) + 1;
      target.SetHitPoints(target.GetHitPoints() - damage);
      if ((rollDie(20, false, false) + target.GetStrmod()) < 11) {
        // isGrappled=true;
      }
    }
  }
}; // end of giant frog

#endif