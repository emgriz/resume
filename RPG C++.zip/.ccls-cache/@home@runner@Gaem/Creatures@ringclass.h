#ifndef RINGCLASS_H
#define RINGCLASS_H
#include "gamelogicfunction.h"
#include "item.h"
#include <string>

class Ring : public Item {
public:
  std::string name;
  int intelligence;
  int wisdom;
  int charisma;
  int strength;
  int weight;

  void setName(std::string nameset) { name = nameset; }
  void setIntelligence(int intelligenceset) { intelligence = intelligenceset; }
  void setWisdom(int wisdomset) { wisdom = wisdomset; }
  void setCharisma(int charismaset) { charisma = charismaset; }
  void setStrength(int strengthset) { strength = strengthset; }
  void setWeight(int weightset) { weight = weightset; }

  std::string getName() { return name; }
  int getIntelligence() { return intelligence; }
  int getWisdom() { return wisdom; }
  int getCharisma() { return charisma; }
  int getStrength() { return strength; }
  int getWeight() { return weight; }

  Ring() = default;
};

#endif