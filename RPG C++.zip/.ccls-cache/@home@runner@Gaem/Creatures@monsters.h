#ifndef MONSTERS_H
#define MONSTERS_H
#include "gamelogicfunction.h"
#include "monsterclass.h"
#include "creatureclass.h"
#include <string>

class Wolf : public Monster {
public:
  Wolf() : Monster() {
    name = "Wolf";
    strength = 12;
    dexterity = 15;
    constitution = 12;
    intelligence = 3;
    wisdom = 12;
    charisma = 6;
    hitPoints = 11;
    armorClass = 13;
    strmod = 1;
    dexmod = 2;
    conmod = 1;
    intmod = -4;
    wismod = 1;
    chamod = -2;
  };

  void Bite(Creature &target) {
    int r = logic.rollDie(20, false, false) + 4;
    if (r > target.GetArmorClass()) {
      int damage =
          logic.rollDie(4, false, false) + logic.rollDie(4, false, false) + 2;
      target.SetHitPoints(target.GetHitPoints() - damage);
      std::cout << "The " << name << " bites " << target.GetName() << " for "
                << damage << " damage!\n";
    } else {
      std::cout << "The Wolf tries to bite " << target.GetName()
                << " but misses!\n";
    }
  }; // end Bite

  void chooseAction(Creature &target) {

    if (hitPoints <= 5) {
      int x = (rand() % 2) + 1;
      if (x == 1) {
        Bite(target);
      } else {
        IsFleeing = true;
      }
    } // end if statement
    else {
      Bite(target);
    } // end else statement
  };  // end ChooseAction

private:
  gameLogicFunctions logic;
}; // end Wolf

class Guard : public Monster {
public:
  std::string name;
  Guard() : Monster() {
    name = "Guard";
    strength = 13;
    dexterity = 12;
    constitution = 12;
    intelligence = 10;
    wisdom = 11;
    charisma = 10;
    hitPoints = 11;
    armorClass = 16;
    strmod = 1;
    dexmod = 1;
    conmod = 1;
    intmod = 0;
    wismod = 0;
    chamod = 0;
				MapSymbol = 'G';
  }

  void Spear(Creature &target) {
    int roll = logic.rollDie(20, false, false) + 3;
    if (roll > target.GetArmorClass()) {
      int damage = logic.rollDie(8, false, false) + 1;
      target.SetHitPoints(target.GetHitPoints() - damage);
      std::cout << "The Guard thrusts its spear at " << target.GetName()  << " and deals " << damage << " damage!\n";
    }
			else {
				std::cout << "The Guard thrusts its spear at " << target.GetName()  << " but misses!" << std::endl;
			}
			
  };

  void chooseAction(Creature &target) {
    if (hitPoints <= 5) {
      int x = (rand() % 2)+1;
      if (x == 1) {
        Spear(target);
      } else {
        IsFleeing = true;
      } // end else
    }   // end if
    else {
      Spear(target);
    }
  }; // end ChooseAction

private:
  gameLogicFunctions logic;
}; // end Guard

class Noble : public Monster {
public:
  Noble() : Monster() {
    name = "Noble";
    strength = 11;
    dexterity = 12;
    constitution = 11;
    intelligence = 12;
    wisdom = 14;
    charisma = 16;
    hitPoints = 9;
    armorClass = 15;
    strmod = 0;
    dexmod = 1;
    conmod = 0;
    intmod = 1;
    wismod = 2;
    chamod = 3;
  }

  void Rapier(Creature &target) {
    int r = logic.rollDie(20, false, false) + 3;
    if (r > target.GetArmorClass()) {
      int damage = logic.rollDie(8, false, false) + 1;
      target.SetHitPoints(target.GetHitPoints() - damage);
      std::cout << "The Noble thrusts with its rapier and deals " << damage
                << " damage to " << target.GetName() << "!\n";
    } else {
      std::cout << "The Noble tries to thrust with its rapier but misses the "
                   "target!\n";
    }
  };

  virtual void chooseAction (Creature &target) override {
    if (hitPoints <= 4) {
      int x = (rand() % 2)+1;
      if (x == 1) {
        Rapier(target);
      } else {
        IsFleeing = true;
      }
    } else {
      Rapier(target);
    }
  };

private:
  gameLogicFunctions logic;
};

class Hobgoblin : public Monster {
public:
  Hobgoblin() : Monster() {
    name = "Hobgoblin";
    strength = 13;
    dexterity = 12;
    constitution = 12;
    intelligence = 10;
    wisdom = 10;
    charisma = 9;
    hitPoints = 11; 	
    armorClass = 18;
    strmod = 1;
    dexmod = 1;
    conmod = 1;
    intmod = 0;
    wismod = 0;
    chamod = -1;
  }
  gameLogicFunctions logic;

  void Longsword(Creature &target) {
    int roll = logic.rollDie(20, false, false) + 3;
    if (roll > target.GetArmorClass()) {
      int damage = logic.rollDie(10, false, false) + 1;
      target.SetHitPoints(target.GetHitPoints() - damage);
      std::cout << "The Hobgoblin cuts " << target.GetName()
                << " with its longsword for " << damage << " slashing damage!"
                << std::endl;
    } else {
      std::cout
          << "The Hobgoblin swings its longsword but misses the target!\n";
    }
  };

  void Longbow(Creature &target) {
    int roll = logic.rollDie(20, false, false) + 3;
    if (roll > target.GetArmorClass()) {
      int damage = logic.rollDie(8, false, false) + 1;
      target.SetHitPoints(target.GetHitPoints() - damage);
      std::cout << "The Hobgoblin pierces " << target.GetName()
                << " with its longbow for " << damage << " piercing damage!"
                << std::endl;
    } else {
      std::cout << "The Hobgoblin misses with its longbow!\n";
    }
  }

  void chooseAction(Creature &target) {
			
    int x = (rand() % 3)+1;
    if (hitPoints <= 5) {
      if (x == 1) {
        Longsword(target);
      }
      if (x == 2) {
        Longbow(target);
      } else {
        IsFleeing = true;
      }
    } else {
      int x = (rand() % 1)+1;
      if (x == 1) {
        Longsword(target);}
        if (x == 2) {
          Longbow(target);
        }
      }
    
  }; // end chooseAction

}; // end Hobgoblin

class Bugbear : public Monster {
public:
  Bugbear() : Monster() {
    name = "Bugbear";
    strength = 15;
    dexterity = 14;
    constitution = 13;
    intelligence = 8;
    wisdom = 11;
    charisma = 9;
    hitPoints = 27;
    armorClass = 16;
    strmod = 2;
    dexmod = 2;
    conmod = 1;
    intmod = -1;
    wismod = 0;
    chamod = -1;
  };

  void Morning_Star(Creature &target) {
    int roll = logic.rollDie(20, false, false) + 4;
    if (roll > target.GetArmorClass()) {
      int damage = logic.rollDie(8, false, false) + 5;
      target.SetHitPoints(target.GetHitPoints() - damage);
      std::cout << "The bugbear hits " << target.GetName()
                << " with a spiky bonk stick for " << damage << " damage!\n";
    } 
				else {
      std::cout << "The bugbear tries to hit " << target.GetName() << " with a spiky bonk stick, but misses!\n";
    }
  };

  void Javelin(Creature &target) {
    int r = logic.rollDie(20, false, false) + 4;
    if (r > target.GetArmorClass()) {
      int damage = logic.rollDie(6, false, false) + 5; // d6, twice
      target.SetHitPoints(target.GetHitPoints() - damage);
      std::cout << "The bugbear hits " << target.GetName()
                << "with a javelin for " << damage << " damage!\n";
    } else {
      std::cout << "The bugbear misses its javelin!\n";
    }
  }; // end Javelin

  void chooseAction(Creature &target) {
    if (hitPoints <= 13) {
      int x = (rand() % 2)+1;
					std::cout << x << std::endl;
      if (x == 1) {
        Morning_Star(target);
      }
      if (x == 2) {
        Javelin(target);
      } else {
								std::cout << "Bugbear flees!" << std::endl;
        IsFleeing = true;
      }
    } else {
      int x = (rand() % 1)+1;
      if (x == 1) {
        Morning_Star(target);
      }
      if (x == 2) {
        Javelin(target);
      }
    }
  } // end ChooseAction
public:
  gameLogicFunctions logic;
}; // end Bugbear

class GiantFrog : public Monster {
public:
  GiantFrog() : Monster() {
    name = "Giant Frog";
    strength = 12;
    dexterity = 13;
    constitution = 11;
    intelligence = 2;
    wisdom = 10;
    charisma = 3;
    hitPoints = 18;
    armorClass = 11;
    strmod = 1;
    dexmod = 1;
    conmod = 0;
    intmod = -4;
    wismod = 0;
    chamod = -4;
  };

  void Frog_Bite(Creature &target) {
    int r = logic.rollDie(20, false, false) + 3;
    if (r > target.GetArmorClass()) {
      int damage = logic.rollDie(6, false, false) + 1;
      target.SetHitPoints(target.GetHitPoints() - damage);
      std::cout << "The frog bites " << target.GetName() << " for " << damage
                << " damage!\n";

      if ((logic.rollDie(20, false, false) + target.GetStrmod()) < 11) {
        std::cout << "You've been grappled!";
      }
    } else {
      std::cout << "The frog tries to chomp on " << target.GetName()
                << " but misses!\n";
    }
  }; // end Frog_Bite

  void chooseAction(Creature &target) {
    if (hitPoints <= 9) {
      int x = (rand() % 2) + 1;
      if (x == 1) {
        Frog_Bite(target);
      } else {
        IsFleeing = true;
      }
    } else {
      Frog_Bite(target);
    }
  }

private:
  gameLogicFunctions logic;
}; // end of giant frog

class Bandit : public Monster {
public:
  Bandit() : Monster() {
    name = "Bandit";
    strength = 11;
    dexterity = 12;
    constitution = 12;
    intelligence = 10;
    wisdom = 10;
    charisma = 10;
    hitPoints = 11;
    armorClass = 12;
    strmod = 0;
    dexmod = 1;
    conmod = 1;
    intmod = 0;
    wismod = 0;
    chamod = 0;
  };

void Scimitar(Creature &target) {
  int r = logic.rollDie(20, false, false) + 3;
  if (r > target.GetArmorClass()) {
    int damage = logic.rollDie(6, false, false) + 1;
    target.SetHitPoints(target.GetHitPoints() - damage);
    std::cout << "The Bandit attacks with a scimitar " << target.GetName() << " for " << damage
              << " damage!\n";

    if ((logic.rollDie(20, false, false) + target.GetStrmod()) < 11) {
      std::cout << "You've been slashed!";
    }
  } else {
    std::cout << "The Bandit tries to hit you with a scimitar " << target.GetName()
              << " but misses!\n";
  }
}; // end Scimitar

void Light_Crossbow(Creature &target) {
  int r = logic.rollDie(20, false, false) + 3;
  if (r > target.GetArmorClass()) {
    int damage = logic.rollDie(8, false, false) + 1;
    target.SetHitPoints(target.GetHitPoints() - damage);
    std::cout << "The Bandit shoots you with a crossbow " << target.GetName() << " for " << damage
              << " damage!\n";

    if ((logic.rollDie(20, false, false) + target.GetStrmod()) < 11) {
      std::cout << "You've been shot!";
    }
  } else {
    std::cout << "The Bandit shoots at you " << target.GetName()
              << " but misses!\n";
  }
}; // end light crossbow

void chooseAction(Creature &target) {
  if (hitPoints <= 13) {
    int x = (rand() % 2)+1;
        std::cout << x << std::endl;
    if (x == 1) {
      Scimitar(target);
    }
    if (x == 2) {
      Light_Crossbow(target);
    } else {
              std::cout << "Bandit flees!" << std::endl;
      IsFleeing = true;
    }
  } else {
    int x = (rand() % 1)+1;
    if (x == 1) {
      Scimitar(target);
    }
    if (x == 2) {
      Light_Crossbow(target);
    }
  }
} 
private:
  gameLogicFunctions logic;
}; // end of bandit

class Scout : public Monster {
public:
  Scout() : Monster() {
    name = "Scout";
    strength = 11;
    dexterity = 14;
    constitution = 12;
    intelligence = 11;
    wisdom = 13;
    charisma = 11;
    hitPoints = 16;
    armorClass = 13;
    strmod = 0;
    dexmod = 2;
    conmod = 1;
    intmod = 0;
    wismod = 1;
    chamod = 0;
  };

void Shortsword(Creature &target) {
  int r = logic.rollDie(20, false, false) + 4;
  if (r > target.GetArmorClass()) {
    int damage = logic.rollDie(6, false, false) + 2;
    target.SetHitPoints(target.GetHitPoints() - damage);
    std::cout << "The Scout attacks with a shortsword" << target.GetName() << " for " << damage
              << " damage!\n";

    if ((logic.rollDie(20, false, false) + target.GetStrmod()) < 11) {
      std::cout << "You've been stabbed!";
    }
  } else {
    std::cout << "The Scout tries to hit you with a shortsword" << target.GetName()
              << " but misses!\n";
  }
}; // end shortsword

void Longbow(Creature &target) {
  int r = logic.rollDie(20, false, false) + 4;
  if (r > target.GetArmorClass()) {
    int damage = logic.rollDie(8, false, false) + 2;
    target.SetHitPoints(target.GetHitPoints() - damage);
    std::cout << "The Scout shoots you with a crossbow " << target.GetName() << " for " << damage
              << " damage!\n";

    if ((logic.rollDie(20, false, false) + target.GetStrmod()) < 11) {
      std::cout << "You've been shot!";
    }
  } else {
    std::cout << "The Scout shoots at you " << target.GetName()
              << " but misses!\n";
  }
}; // end light crossbow

void chooseAction(Creature &target) {
  if (hitPoints <= 13) {
    int x = (rand() % 2)+1;
        std::cout << x << std::endl;
    if (x == 1) {
      Shortsword(target);
    }
    if (x == 2) {
      Longbow(target);
    } else {
              std::cout << "Scout flees!" << std::endl;
      IsFleeing = true;
    }
  } else {
    int x = (rand() % 1)+1;
    if (x == 1) {
      Shortsword(target);
    }
    if (x == 2) {
      Longbow(target);
    }
  }
} 
private:
  gameLogicFunctions logic;
}; // end of scout

class OldCroaker : public Monster {
public:
  OldCroaker() : Monster() {
    name = "Old Croaker";
    strength = 15;
    dexterity = 13;
    constitution = 13;
    intelligence = 2;
    wisdom = 10;
    charisma = 3;
    hitPoints = 39;
    armorClass = 11;
    strmod = 2;
    dexmod = 1;
    conmod = 1;
    intmod = -4;
    wismod = 0;
    chamod = -4;
  };

	void Croaker_Heal(Creature&target) {
		int r = logic.rollDie(20, false, false) + 4;
		this->hitPoints += r;
		std::cout << "The Croaker heals itself for " << r << " hit points!\n";
	}//end croaker heal

  void Croaker_Bite(Creature &target) {
    int r = logic.rollDie(20, false, false) + 4;
    if (r > target.GetArmorClass()) {
      int damage = 0;
      int poison_damage = 0;
      for (int i = 0; i < 10; ++i) {
          damage += logic.rollDie(10, false, false) + 2;
      }
      for (int i = 0; i < 7; ++i) {
          poison_damage += logic.rollDie(10, false, false) + 2;
      }
      target.SetHitPoints(target.GetHitPoints() - damage - poison_damage);
      std::cout << "The frog bites " << target.GetName() << " for " << damage
                << " damage!\n";

      if ((logic.rollDie(20, false, false) + target.GetStrmod()) < 11) {
        std::cout << "You've been grappled!";
      }
    } else {
      std::cout << "The frog tries to chomp on " << target.GetName()
                << " but misses!\n";
    }
  }; // end Croaker_Bite

  void chooseAction(Creature &target) {
    if (hitPoints <= 9) {
      int x = (rand() % 3) + 1;
      if (x == 1) {
        Croaker_Bite(target);
      } if(x==2) {
        IsFleeing = true;
      }
					if(x==3){
						Croaker_Heal(target);
					}
    } else {
      Croaker_Bite(target);
    }
  }

private:
  gameLogicFunctions logic;
}; // end of old croaker

class Cult_Fanatic : public Monster {
public:
  Cult_Fanatic() : Monster() {
    name = "Fanatic";
    strength = 11;
    dexterity = 14;
    constitution = 12;
    intelligence = 10;
    wisdom = 13;
    charisma = 14;
    hitPoints = 33;
    armorClass = 13;
    strmod = 0;
    dexmod = 2;
    conmod = 1;
    intmod = 0;
    wismod = 1;
    chamod = 2;
  };

  void Dagger(Creature &target) {
    int r = logic.rollDie(20, false, false) + 4;
    if (r > target.GetArmorClass()) {
      int damage = logic.rollDie(4, false, false) + 2;
      target.SetHitPoints(target.GetHitPoints() - damage);
      std::cout << "The Fanatic lunges towards you with a dagger and deals" << damage
                << " damage to " << target.GetName() << "!\n";
    } else {
      std::cout << "The Fanatic tries to stab with its dagger but misses the "
                   "target!\n";
    }
  };//end dagger

  virtual void chooseAction (Creature &target) override {
    if (hitPoints <= 4) {
      int x = (rand() % 2)+1;
      if (x == 1) {
        Dagger(target);
      } else {
        IsFleeing = true;
      }
    } else {
      Dagger(target);
    }
  };//end cult_fanatic

private:
  gameLogicFunctions logic;
};

class Cultist : public Monster {
public:
  Cultist() : Monster() {
    name = "Cultist";
    strength = 11;
    dexterity = 12;
    constitution = 10;
    intelligence = 10;
    wisdom = 11;
    charisma = 10;
    hitPoints = 9;
    armorClass = 12;
    strmod = 0;
    dexmod = 1;
    conmod = 0;
    intmod = 0;
    wismod = 0;
    chamod = 0;
  };

  void Cultist_Scimitar(Creature &target) {
    int r = logic.rollDie(20, false, false) + 3;
    if (r > target.GetArmorClass()) {
      int damage = logic.rollDie(6, false, false) + 1;
      target.SetHitPoints(target.GetHitPoints() - damage);
      std::cout << "The Cultist slashes at you with a scimitar and deals" << damage
                << " damage to " << target.GetName() << "!\n";
    } else {
      std::cout << "The Cultist tries to cut with its scimitar but misses the "
                   "target!\n";
    }
  };//end scimitar

  virtual void chooseAction (Creature &target) override {
    if (hitPoints <= 4) {
      int x = (rand() % 2)+1;
      if (x == 1) {
        Cultist_Scimitar(target);
      } else {
        IsFleeing = true;
      }
    } else {
      Cultist_Scimitar(target);
    }
  };//end cultist

private:
  gameLogicFunctions logic;
};

#endif