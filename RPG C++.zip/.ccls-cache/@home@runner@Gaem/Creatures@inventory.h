#ifndef INVENTORY_H
#define INVENTORY_H
#include "item.h"
#include <iostream>

class Inventory {
public:
  struct inventoryNode {
    Item *item;
    inventoryNode *nextItem;
    // constructor
    inventoryNode(Item *i, inventoryNode *n = nullptr) : item(i), nextItem(n) {}
  };

  inventoryNode *head;

  void addItem(Item *newItem) {
    weightCounter += newItem->getWeight();
    if (weightCounter > weightLimit) {
      std::cout << "That item is too heavy!" << std::endl;
      return;
    } else {
      if (head == nullptr) {
        head = new inventoryNode(newItem);
        return;
      }
      inventoryNode *temp = head;
      while (temp->nextItem != nullptr) {
        temp = temp->nextItem;
      }
      temp->nextItem = new inventoryNode(newItem);
    }
  };

  Item *removeItem(const std::string &itemName) {
    if (head == nullptr) {
      std::cout << "Inventory is empty." << std::endl;
      return nullptr;
    }
    if (head->item->getName() == itemName) {
      inventoryNode *temp = head;
      head = head->nextItem;
      Item *removedItem = temp->item;
      weightCounter -= removedItem->getWeight();
      delete temp;
      return removedItem;
    }
    inventoryNode *prev = head;
    inventoryNode *current = head->nextItem;
    while (current != nullptr) {
      if (current->item->getName() == itemName) {
        prev->nextItem = current->nextItem;
        Item *removedItem = current->item;
        weightCounter -= removedItem->getWeight();
        delete current;
        return removedItem;
      }
      prev = current;
      current = current->nextItem;
    }
    std::cout << "Item not found in inventory." << std::endl;
    return nullptr;
  };

  Item *searchItem(const std::string &itemName) const {
    inventoryNode *temp = head;
    while (temp != nullptr) {
      if (temp->item->getName() == itemName) {
        return temp->item;
      }
      temp = temp->nextItem;
    }
    return nullptr;
  };

  int getWeightLimit() { return weightLimit; };

  int getWeightCounter() { return weightCounter; };

  void updateGold(int amount) { gold += amount; };

  int getGold() { return gold; };

  void printInventory() const {
    inventoryNode *temp = head;
    std::cout << "Inventory:" << std::endl;
    while (temp) {
      std::cout << "- " << temp->item->getName() << std::endl;
      temp = temp->nextItem;
    }
  };

private:
  int weightCounter;
  int weightLimit = 200;
  int gold = 0;
};

#endif