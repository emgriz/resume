#ifndef WEAPONS_H
#define WEAPONS_H
#include "weaponclass.h"

class Longsword : public Weapon {};
class Dagger : public Weapon {};
class Handaxe : public Weapon {};
class Club : public Weapon {};
class Poisoned_Blade : public Weapon{
  public:
  int onhitPoison = 5;
  int damageDie = 4;
  int damageType = 2;
  int damageModifier = 1;
   

};

#endif