#ifndef PLAYERCLASS_H
#define PLAYERCLASS_H

#include "creatureclass.h"     // Assuming Creature is included here
#include "gamelogicfunction.h" // Include the header for gameLogicFunctions class

#include <string>
#include <vector>
#include "rings.h"
#include "armor.h"
#include "monsters.h"
#include "monsterclass.h"
#include "weaponclass.h"
#include "spells.h"
#include <unistd.h>
// Player class definition here

class Player : public Creature {
public:
int healingpotionsleft = 3;
std::vector <Spell*> UnlockedSpells;
  // Constructors
  Player() : Creature() {
			healingpotionsleft = 3;
    // level = 1;
    // experience = 0;
    // Class = "DefaultClass";
    // Race = "DefaultRace";
    defending = false; // Initialize defending flag
  }

  // Getters and setters
  // int GetLevel() { return level; }
  // int GetExperience() { return experience; }
  //   std::string GetClass() { return Class; }
  // void SetLevel(int levelset) { level = levelset; }
  // void SetExperience(int experienceset) { experience = experienceset; }
  //  void SetClass(std::string classset) { Class = classset; }

  // Player actions
		void ObtainSpell(Spell* spell){
UnlockedSpells.push_back(spell);
		}

  void Attack(Creature& target) {
    gameLogicFunctions logic;
    int roll = logic.rollDie(20,false,false);
	
    int damage = logic.rollDie(Equipped_Weapon->getDamageDie(),false,false) + Equipped_Weapon->getdamageModifier();
			int hitAttempt = roll + Equipped_Weapon->getHitMod();
			sleep(1);
if(hitAttempt>target.GetArmorClass()){
	std::cout << "Congratulations, " << name << "!" << " You hit " << target.GetName() << "with " << Equipped_Weapon->getName() << " for " << damage << " damage!" << std::endl;
	target.SetHitPoints(target.GetHitPoints() - damage);
if(Equipped_Weapon->onhitPoison!=0){target.poison+=Equipped_Weapon->onhitPoison;}}
			else{
				// miss
				std::cout << "You missed " << target.GetName() << " with " << Equipped_Weapon->getName() << "." << std::endl;
			}
    
  }

  void Defend() {
    std::cout << "You're defending!" << std::endl;
    SetarmorClass(GetArmorClass() + 2);
    std::cout << "AC Status: " << GetArmorClass() << std::endl;
    defending = true; // Set defending flag to true
  }

  bool Flee() {
    std::cout << "You attempt to flee!" << std::endl;
    gameLogicFunctions logic;
    int fleeAttempt = logic.rollDie(20, false, false) + GetDexmod();
    if (fleeAttempt > 15) {
      std::cout << "You have successfully escaped!" << std::endl;
      return true;
    } else {
      std::cout << "You failed to escape!" << std::endl;
      return false;
    }
  }

void Spellbook() {
	std::cout << "Available spells:  ";
	std::cout << std::endl;
for (int i=0; i<UnlockedSpells.size(); i++){
		std::cout << i+1 << ". " << UnlockedSpells[i]->getName() << "\n";
}
	
}




  // Function to reset defending flag after a turn
  void StartTurn() {
    if (defending) {
      SetarmorClass(GetArmorClass() -
                    2); // Decrease AC by 2 if player was defending
      std::cout << "Defensive stance ends. Status: " << GetArmorClass()
                << std::endl;
      defending = false; // Reset defending flag
    }
  }


void EquipWeapon(Weapon& weapon){
	this->Equipped_Weapon = &weapon;
}
  

  int level;
  int experience;
  std::string Class;
  std::string Race;
  Weapon* Equipped_Weapon;
  Armor* Equipped_Armor;
  Ring* Equipped_Ring;
  bool defending; // Flag to track whether player is currently defending
};

#endif