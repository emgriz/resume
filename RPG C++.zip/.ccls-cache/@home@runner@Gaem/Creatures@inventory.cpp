void addWeapon(Weapon *newWeapon) {
  if (head == nullptr) {
    head = new weaponNode(newWeapon);
    return;
  }
  weaponNode *temp = head;
  while (temp->nextWeapon != nullptr) {
    temp = temp->nextWeapon;
  }
  temp->nextWeapon = new weaponNode(newWeapon);
};