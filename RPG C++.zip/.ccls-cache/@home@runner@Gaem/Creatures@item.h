#ifndef ITEM_H
#define ITEM_H
#include <string>
#include <vector>

class Item {
public:
  std::string name;
  float goldValue;
  float weight;
  std::string getName() { return name; }
  float getgoldValue() { return goldValue; }
  float getWeight() { return weight; }
  void setName(std::string nam) { name = nam; }
  void setgoldValue(float goldValu) { goldValue = goldValu; }
  void setWeight(float weigh) { weight = weigh; }

  Item(const std::string &itemName, float itemWeight)
      : name(itemName), weight(itemWeight) {}
  Item() = default;
};

#endif